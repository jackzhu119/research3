"""R1 management-only memory recovery with fresh, read-only Slurm cycles.

This process never starts a scientific action, probes a GPU, submits a job or
cancels an allocation. Existing native workers receive the native queue and
leave normally when the original protocol reaches completion.
"""
from __future__ import annotations

import argparse
from contextlib import contextmanager
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import signal
import stat
import subprocess
import sys
import tempfile
import threading
import time

HERE = Path(__file__).resolve().parent
REPAIR_ID = 'paper3-r1-controller-memory-recovery-v1'
RUNTIME = 'runs/training_campaign_parallel_v1'
OLD_PACKAGE = '2bfd664251ee5d1bcaf5'
OLD_SUPERVISOR = '43aeea5f1714c8171352b3ec2c86a2e907c8b49d95431b96da33fe8b9f8db0c7'
LEGACY_FILES = {
    'parallel_runtime.py': 'c9eb4f4a0e38f2ecfe724358451c1fe60615e284d71c98f639b3866ef40124cd',
    'atomic_io.py': '46403f6b4cf3496ed19b3a665abb4515a8b748aad9d5eee1ec48755de11fa5d4',
}
MAX_RECORD_BYTES = 2 * 1024 * 1024


def utc():
    return time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())


def emit(event, **fields):
    print(json.dumps(dict(event=event, utc=utc(), **fields), ensure_ascii=False), flush=True)


def read(path, default=None):
    try:
        with Path(path).open('rb') as handle:
            size = os.fstat(handle.fileno()).st_size
            if size > MAX_RECORD_BYTES:
                raise ValueError('MANAGEMENT_RECORD_TOO_LARGE: ' + str(path))
            raw = handle.read(MAX_RECORD_BYTES + 1)
        if len(raw) > MAX_RECORD_BYTES:
            raise ValueError('MANAGEMENT_RECORD_TOO_LARGE: ' + str(path))
        return json.loads(raw)
    except FileNotFoundError:
        return default


def atomic(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    raw = (json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2) + '\n').encode()
    fd, temporary = tempfile.mkstemp(prefix='.r1-memory-', dir=path.parent)
    try:
        with os.fdopen(fd, 'wb') as handle:
            handle.write(raw)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
    finally:
        Path(temporary).unlink(missing_ok=True)


@contextmanager
def lock(path, blocking=False):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('a') as handle:
        fcntl.flock(handle, fcntl.LOCK_EX | (0 if blocking else fcntl.LOCK_NB))
        yield handle


def identity(pid, proc_root=Path('/proc')):
    try:
        if type(pid) is not int or pid <= 1:
            return None
        folder = Path(proc_root) / str(pid)
        if folder.stat().st_uid != os.getuid():
            return None
        fields = (folder / 'stat').read_text().rsplit(')', 1)[1].split()
        if fields[0] in ('Z', 'X', 'x'):
            return None
        argv = [v.decode('utf-8') for v in (folder / 'cmdline').read_bytes().split(b'\0') if v]
        return dict(pid=pid, uid=folder.stat().st_uid, start_ticks=fields[19], argv=argv)
    except (OSError, ValueError, IndexError, UnicodeError):
        return None


def option(argv, key):
    if not isinstance(argv, list) or argv.count(key) != 1:
        return None
    index = argv.index(key)
    return argv[index + 1] if index + 1 < len(argv) else None


def script_argument(argv):
    if not argv or Path(argv[0]).resolve() != Path(sys.executable).resolve():
        return None, None
    index = 1
    while index < len(argv) and argv[index] in ('-I', '-S', '-B', '-u', '-E', '-s', '-O', '-OO'):
        index += 1
    if index >= len(argv):
        return None, None
    return Path(argv[index]).resolve(), index


def regular_owned(path):
    st = Path(path).lstat()
    if not stat.S_ISREG(st.st_mode) or st.st_uid != os.getuid():
        raise ValueError('MANAGEMENT_FILE_NOT_OWNED_REGULAR: ' + str(path))


def legacy_context(home, root):
    home, root = Path(home).resolve(), Path(root).resolve()
    base = home / 'paper3-r1-full-repair'
    work = base / 'work'
    regular_owned(work / 'controller-process.json')
    record = read(work / 'controller-process.json')
    if not isinstance(record, dict) or record.get('root') != str(root):
        raise ValueError('LEGACY_CONTROLLER_RECORD_ROOT_DIFFERS')
    argv = record.get('argv')
    script, index = script_argument(argv)
    expected = base / ('refresh-fixed-' + OLD_SUPERVISOR[:20]) / 'supervisor.py'
    if script != expected or index + 1 >= len(argv) or argv[index + 1] != 'manage':
        raise ValueError('OBSERVED_LEGACY_CONTROLLER_COMMAND_DIFFERS')
    expected_options = {
        '--root': str(root), '--home': str(home), '--work': str(work),
        '--package': str(base / OLD_PACKAGE), '--launch-token': record.get('launch_token'),
    }
    if not record.get('launch_token') or any(option(argv, k) != v for k, v in expected_options.items()):
        raise ValueError('OBSERVED_LEGACY_CONTROLLER_IDENTITY_DIFFERS')
    if '--child' in argv or '--controller' in argv:
        raise ValueError('NOT_AN_R1_MANAGEMENT_PROCESS')
    for name, expected_hash in LEGACY_FILES.items():
        path = script.parent / name
        regular_owned(path)
        if hashlib.sha256(path.read_bytes()).hexdigest() != expected_hash:
            raise ValueError('RETAINED_MANAGEMENT_SOURCE_DIFFERS: ' + name)
    launch = read(root / RUNTIME / 'launch.json')
    if not isinstance(launch, dict):
        raise ValueError('ORIGINAL_LAUNCH_RECORD_REQUIRED')
    package = launch.get('package') or option(launch.get('worker_command'), '--package')
    if not package:
        raise ValueError('ORIGINAL_NATIVE_PACKAGE_REQUIRED')
    return dict(home=home, root=root, work=work, legacy=script.parent,
                native=Path(package).resolve(), record=record)


def same_legacy(record, current):
    return (current is not None and current.get('argv') == record.get('argv')
            and (record.get('start_ticks') is None or current.get('start_ticks') == record['start_ticks']))


def stop_legacy(context, *, process=identity, send=os.kill, clock=time.monotonic, sleep=time.sleep,
                pidfd_open=None, pidfd_send=None):
    """Stop only the recorded CPU supervisor, binding its identity for escalation.

    Python can remain alive after its main thread fails when non-daemon executor
    threads survive and its installed TERM handler merely sets an event. A TERM
    timeout therefore escalates only this exact management process to KILL. The
    original controller lock still excludes a pending uninterruptible process
    from concurrent queue publication by the replacement guardian.
    """
    record = context['record']
    current = process(record.get('pid'))
    if not same_legacy(record, current):
        return dict(status='LEGACY_MANAGER_ABSENT_OR_PID_REUSED', signals=[])
    # Persist identity before signaling; subsequent retries never infer ownership
    # from a bare PID or from the Slurm scientific worker's existence.
    atomic(context['work'] / 'memory-recovery-old-manager.json', dict(
        repair_id=REPAIR_ID, identity=current, scientific_jobs_signalled=0))
    if process(record['pid']) != current:
        return dict(status='LEGACY_MANAGER_IDENTITY_CHANGED', signals=[])
    descriptor = None
    open_fd = pidfd_open or getattr(os, 'pidfd_open', None)
    send_fd = pidfd_send or getattr(signal, 'pidfd_send_signal', None)
    # Injected send functions are test/simulation transports. Production binds
    # the exact PID through pidfd when the school's kernel supports it.
    if (send is os.kill or pidfd_open is not None) and open_fd is not None and send_fd is not None:
        try:
            descriptor = open_fd(record['pid'], 0)
        except OSError:
            descriptor = None
    requested = []
    def verified_send(sig):
        if process(record['pid']) != current:
            return False
        if descriptor is not None:
            send_fd(descriptor, sig, None, 0)
        else:
            send(record['pid'], sig)
        requested.append(signal.Signals(sig).name)
        try:
            emit('R1_LEGACY_CPU_MANAGER_SIGNAL_SENT', pid=record['pid'],
                 signal_name=signal.Signals(sig).name,
                 wait_seconds=12 if sig == signal.SIGTERM else 5,
                 scientific_jobs_signalled=0, process_groups_signalled=0)
        except OSError:
            pass
        return True
    def result(status):
        return dict(status=status, signals=requested, pidfd_bound=descriptor is not None,
            scientific_jobs_signalled=0, process_groups_signalled=0)
    try:
        try:
            if not verified_send(signal.SIGTERM):
                return result('LEGACY_MANAGER_IDENTITY_CHANGED')
        except ProcessLookupError:
            return result('LEGACY_MANAGER_ENDED')
        until = clock() + 12
        while process(record['pid']) == current and clock() < until:
            sleep(.1)
        if process(record['pid']) != current:
            return result('LEGACY_CPU_MANAGER_STOPPED')
        # Identity is checked once more immediately before escalation. pidfd
        # also prevents an intervening PID reuse from redirecting this signal.
        try:
            if not verified_send(signal.SIGKILL):
                return result('LEGACY_MANAGER_IDENTITY_CHANGED_AFTER_TERM')
        except ProcessLookupError:
            return result('LEGACY_CPU_MANAGER_STOPPED')
        until = clock() + 5
        while process(record['pid']) == current and clock() < until:
            sleep(.1)
        if process(record['pid']) == current:
            return result('LEGACY_CPU_MANAGER_KILL_PENDING_CONTROLLER_LOCK_RETAINED')
        return result('LEGACY_CPU_MANAGER_STOPPED')
    finally:
        if descriptor is not None:
            os.close(descriptor)


def read_only_runner(command, **kwargs):
    """Defense against hidden scheduler mutation, independent of submit=False."""
    if not isinstance(command, (tuple, list)) or not command:
        raise ValueError('INVALID_SLURM_READ_COMMAND')
    executable = Path(command[0]).name
    if executable not in ('squeue', 'sacct') and not (
        executable == 'scontrol' and len(command) > 1 and command[1] == 'show'
    ):
        raise RuntimeError('MUTATING_SLURM_COMMAND_BLOCKED: ' + executable)
    kwargs['timeout'] = min(float(kwargs.get('timeout', 30)), 30)
    return subprocess.run(command, **kwargs)


def cycle(args):
    """One fresh process: stream receipts, publish native queue, then exit."""
    emit('R1_MEMORY_CYCLE_START', scientific_jobs_signalled=0, jobs_submitted=0)
    source = Path(args.legacy_dir).resolve()
    base = Path(args.home).resolve() / 'paper3-r1-full-repair'
    expected = base / ('refresh-fixed-' + OLD_SUPERVISOR[:20])
    if source != expected:
        raise ValueError('RETAINED_MANAGEMENT_DIRECTORY_DIFFERS')
    for name, digest in LEGACY_FILES.items():
        regular_owned(source / name)
        if hashlib.sha256((source / name).read_bytes()).hexdigest() != digest:
            raise ValueError('RETAINED_MANAGEMENT_SOURCE_DIFFERS: ' + name)
    sys.path.insert(0, str(source))
    spec = importlib.util.spec_from_file_location('_r1_memory_original_parallel', source / 'parallel_runtime.py')
    pr = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = pr
    spec.loader.exec_module(pr)
    sys.path.insert(0, str(HERE))
    import receipt_projection
    original_load = pr.load_operations
    def load(*values, **options):
        env = original_load(*values, **options)
        receipt_projection.install(env['bridge'])
        return env
    pr.load_operations = load
    result = pr.controller_loop(Path(args.root), Path(args.native_package), Path(args.work),
        submit=False, runner=read_only_runner, once=True, launch_token=args.token)
    if result.get('status') != 'RUNNING':
        raise RuntimeError('NATIVE_QUEUE_OBSERVATION_NOT_PUBLISHED: ' + str(result.get('status')))
    queue = read(Path(args.root) / RUNTIME / 'queue.json', {})
    if queue.get('phase') != result.get('phase'):
        raise RuntimeError('NATIVE_PUBLISHED_QUEUE_PHASE_DIFFERS')
    inflight = result.get('scheduler', {}).get('inflight_jobs')
    complete = queue.get('status') == 'COMPLETE' and inflight == 0
    value = dict(status='ALL_ORIGINAL_WORK_COMPLETE' if complete else 'QUEUE_PUBLISHED',
        phase=result.get('phase'), queue_status=queue.get('status'), inflight_jobs=inflight,
        ready_actions=len(queue.get('ready_actions', [])), retired_slots=queue.get('retired_slots', []),
        queue_updated_at=queue.get('updated_utc'), all_original_complete=complete,
        scientific_jobs_signalled=0, jobs_submitted=0, updated_utc=utc())
    atomic(args.result, value)
    emit('R1_MEMORY_CYCLE_FINISHED', **value)
    return value


def run_cycle(args, sequence, *, popen=subprocess.Popen, stop=None):
    stop = stop or threading.Event()
    result = Path(args.work) / ('memory-cycle-%s.json' % args.token)
    result.unlink(missing_ok=True)
    command = [sys.executable, '-I', '-S', '-B', '-u', str(HERE / 'recovery.py'), '--cycle',
        '--home', str(args.home), '--root', str(args.root), '--work', str(args.work),
        '--legacy-dir', str(args.legacy_dir), '--native-package', str(args.native_package),
        '--token', args.token, '--result', str(result)]
    child = popen(command, stdin=subprocess.DEVNULL, close_fds=True, start_new_session=True)
    deadline = time.monotonic() + 90
    try:
        while child.poll() is None:
            if stop.wait(.1):
                raise RuntimeError('GUARDIAN_STOP_REQUESTED')
            if time.monotonic() >= deadline:
                raise TimeoutError('MANAGEMENT_CYCLE_EXCEEDED_90_SECONDS')
        if child.returncode:
            raise RuntimeError('MANAGEMENT_CYCLE_EXIT_%s' % child.returncode)
        value = read(result)
        if not isinstance(value, dict) or value.get('status') not in ('QUEUE_PUBLISHED', 'ALL_ORIGINAL_WORK_COMPLETE'):
            raise RuntimeError('MANAGEMENT_CYCLE_RESULT_MISSING')
        return value
    finally:
        if child.poll() is None:
            # This handle belongs exclusively to our metadata cycle child.
            # No scientific process is launched by cycle and no process group,
            # Slurm allocation, worker, or unrelated PID is ever signalled.
            child.terminate()
            try:
                child.wait(timeout=3)
            except subprocess.TimeoutExpired:
                child.kill()
                child.wait(timeout=3)


def own_guard(record, process=identity):
    if not isinstance(record, dict) or not record.get('token'):
        return None
    current = process(record.get('pid'))
    if current is None or current.get('argv') != record.get('argv'):
        return None
    script, _ = script_argument(current['argv'])
    if script != HERE / 'recovery.py' or '--guard' not in current['argv']:
        return None
    if option(current['argv'], '--token') != record['token']:
        return None
    if record.get('start_ticks') is not None and current['start_ticks'] != record['start_ticks']:
        return None
    return current


def guard(args, *, stop=None, perform_cycle=run_cycle, maximum_cycles=None):
    stop = stop or threading.Event()
    for sig in (signal.SIGTERM, signal.SIGINT):
        signal.signal(sig, lambda *_: stop.set())
    status_path = Path(args.work) / 'memory-recovery-status.json'
    ready_path = Path(args.work) / 'memory-recovery-ready.json'
    failures = sequence = 0
    with lock(Path(args.work) / 'memory-recovery-guardian.lock'):
        emit('R1_MEMORY_GUARDIAN_STARTED', pid=os.getpid(), receipt_reader='bounded_stream_projection',
             cycle_process='fresh_python_per_iteration', scientific_jobs_signalled=0, jobs_submitted=0)
        while not stop.is_set():
            sequence += 1
            try:
                value = perform_cycle(args, sequence, stop=stop)
                failures = 0
                status = dict(value, repair_id=REPAIR_ID, guardian_pid=os.getpid(), token=args.token,
                    cycle=sequence, status='ALL_ORIGINAL_WORK_COMPLETE' if value['all_original_complete'] else 'RUNNING',
                    original_scientific_files_changed=False, updated_utc=utc())
                atomic(status_path, status)
                atomic(ready_path, dict(repair_id=REPAIR_ID, pid=os.getpid(), token=args.token,
                    first_queue_publication_verified=True, phase=value['phase'], updated_utc=utc()))
                emit('R1_MEMORY_GUARDIAN_PROGRESS', **status)
                if value['all_original_complete']:
                    return status
                delay = 30
            except Exception as error:
                failures += 1
                delay = min(60, 5 * (2 ** min(failures - 1, 4)))
                status = dict(status='RETRYING', repair_id=REPAIR_ID, guardian_pid=os.getpid(),
                    token=args.token, cycle=sequence, consecutive_failures=failures,
                    error_type=type(error).__name__, reason=str(error), retry_seconds=delay,
                    scientific_jobs_signalled=0, jobs_submitted=0,
                    scientific_completion_claimed=False, updated_utc=utc())
                atomic(status_path, status)
                emit('R1_MEMORY_GUARDIAN_RETRY', **status)
            if maximum_cycles is not None and sequence >= maximum_cycles:
                return status
            stop.wait(delay)
    return dict(status='GUARDIAN_STOPPED', scientific_jobs_signalled=0)


def ready_for(work, pid, token):
    value = read(Path(work) / 'memory-recovery-ready.json', {})
    status = read(Path(work) / 'memory-recovery-status.json', {})
    return (value.get('pid') == pid and value.get('token') == token
        and value.get('first_queue_publication_verified') is True
        and status.get('token') == token and status.get('status') in ('RUNNING', 'ALL_ORIGINAL_WORK_COMPLETE'))


def apply(args, *, process=identity, popen=subprocess.Popen, stop_old=stop_legacy):
    context = legacy_context(args.home, args.root)
    work = context['work']
    with lock(work / 'memory-recovery-start.lock'):
        previous = read(work / 'memory-recovery-process.json', {})
        current = own_guard(previous, process=process)
        if current is not None:
            return dict(status='R1_MEMORY_RECOVERY_ALREADY_RUNNING', pid=current['pid'],
                controller_ready=ready_for(work, current['pid'], previous['token']),
                work=str(work), scientific_jobs_signalled=0, jobs_submitted=0)
        old_result = stop_old(context)
        token = hashlib.sha256(os.urandom(32)).hexdigest()
        command = [sys.executable, '-I', '-S', '-B', '-u', str(HERE / 'recovery.py'), '--guard',
            '--home', str(context['home']), '--root', str(context['root']), '--work', str(work),
            '--legacy-dir', str(context['legacy']), '--native-package', str(context['native']), '--token', token]
        with (work / 'memory-recovery.log').open('ab', buffering=0) as log:
            child = popen(command, stdin=subprocess.DEVNULL, stdout=log, stderr=log,
                start_new_session=True, close_fds=True)
        record = dict(repair_id=REPAIR_ID, pid=child.pid, token=token, argv=command,
            root=str(context['root']), started_utc=utc(), start_ticks=None)
        atomic(work / 'memory-recovery-process.json', record)
        deadline = time.monotonic() + 10
        while child.poll() is None and not ready_for(work, child.pid, token) and time.monotonic() < deadline:
            current = process(child.pid)
            if current is not None and current['argv'] == command and record['start_ticks'] is None:
                record['start_ticks'] = current['start_ticks']
                atomic(work / 'memory-recovery-process.json', record)
            time.sleep(.1)
        final = read(work / 'memory-recovery-status.json', {})
        completed = (final.get('token') == token and final.get('status') == 'ALL_ORIGINAL_WORK_COMPLETE')
        status = ('ALL_ORIGINAL_WORK_COMPLETE' if completed else
                  'R1_MEMORY_RECOVERY_START_FAILED' if child.poll() is not None else
                  'R1_MEMORY_RECOVERY_READY' if ready_for(work, child.pid, token) else
                  'R1_MEMORY_RECOVERY_STARTUP_PENDING')
        return dict(status=status, pid=child.pid, work=str(work), prior_manager=old_result,
            controller_ready=ready_for(work, child.pid, token), terminal_can_close=True,
            scientific_jobs_signalled=0, jobs_submitted=0, slurm_jobs_cancelled=0,
            checkpoint_or_receipt_files_changed=False)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__, allow_abbrev=False)
    mode = parser.add_mutually_exclusive_group()
    for name in ('apply', 'check', 'guard', 'cycle'):
        mode.add_argument('--' + name, action='store_true')
    parser.add_argument('--home', type=Path, default=Path.home())
    parser.add_argument('--root', type=Path, default=Path('/public/home/zhuziyuan/projects/paper3'))
    parser.add_argument('--work', type=Path)
    parser.add_argument('--legacy-dir', type=Path)
    parser.add_argument('--native-package', type=Path)
    parser.add_argument('--token')
    parser.add_argument('--result', type=Path)
    args = parser.parse_args(argv)
    if args.guard or args.cycle:
        if not all((args.work, args.legacy_dir, args.native_package, args.token)) or (args.cycle and not args.result):
            parser.error('management child requires explicit paths and token')
        value = cycle(args) if args.cycle else guard(args)
    elif args.apply:
        value = apply(args)
    else:
        context = legacy_context(args.home, args.root)
        status = read(context['work'] / 'memory-recovery-status.json', {})
        value = dict(status='READ_ONLY_CHECK', old_manager_alive=same_legacy(context['record'], identity(context['record'].get('pid'))),
            recovery=status, queue=read(context['root'] / RUNTIME / 'queue.json', {}),
            scientific_jobs_signalled=0, jobs_submitted=0)
    emit('R1_MEMORY_RECOVERY_RESULT', **value)
    return 2 if value.get('status') == 'R1_MEMORY_RECOVERY_START_FAILED' else 0


if __name__ == '__main__':
    raise SystemExit(main())
