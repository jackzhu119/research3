"""Fixed, resumable exploratory EEG update-validity study."""
__version__ = '1.0.0'
