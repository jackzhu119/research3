#!/bin/bash
# Three independent Slurm jobs; each sees its allocated card as cuda:0.
set -eu
R13_PY="$1"
R13_PACKAGE="$2"
R13_PLAN="$3"
R13_SLOT="$4"
export PYTHONUNBUFFERED=1
export PYTHONDONTWRITEBYTECODE=1
export OMP_NUM_THREADS=1
export OPENBLAS_NUM_THREADS=1
export MKL_NUM_THREADS=1
export NUMEXPR_NUM_THREADS=1
export R13_CPU_THREADS="${SLURM_CPUS_PER_TASK:-12}"
export CUBLAS_WORKSPACE_CONFIG=:4096:8
exec "$R13_PY" -I -S -B -u "$R13_PACKAGE/paper3r13/bootstrap.py" parallel-work --plan "$R13_PLAN" --slot "$R13_SLOT" --device cuda:0
