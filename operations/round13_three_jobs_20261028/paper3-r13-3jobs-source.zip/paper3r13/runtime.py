"""One independent R13 allocation, resumable task records and visible progress.

No network, cancellation of existing jobs, resource-limit changes or numerical
imports occur in prepare/submit/status. A scientific worker imports Torch once.
"""
from __future__ import annotations
import argparse
from collections import Counter
import copy
import importlib
import os
from pathlib import Path
import re
import signal
import subprocess
import sys
import threading
import time
import traceback

from .common import (atomic_json, best_effort_json, digest, emit, load_plan, lock,
                     read_json, recipe_payload, safe_read, scientific_receipt,
                     sha_file, task_folder, utc)

SCHEMA = 'paper3-r13-plan-v1'
DEFAULT_M12_PLAN = '/public/home/zhuziyuan/projects/paper3/runs/r12_controlled_mechanism/plan.json'
DEFAULT_PYTHON = '/public/home/zhuziyuan/.venvs/paper3-hpc-cu121-offline/bin/python'
DEFAULT_CONFIG = dict(initial_acquired_positions=12, max_acquired_positions=20,
    rhos=[0., .25, .5, .75, 1.], sentinel_positions=[4, 8],
    source_seeds=[20261018, 20261019, 20261020],
    optimizer=dict(primary_steps=100, secondary_steps=10, theta_learning_rate=.05,
                   theta_l2=.01, theta_radius=.15, head_learning_rate=.01,
                   head_l2=.001, head_penalty_divisor=65),
    scope='EXPLORATORY_DEVELOPMENT_NOT_INDEPENDENT_CONFIRMATION',
    gates_on_significance=False, exhaustive_fixed_matrix=True)
LIVE = {'PENDING', 'RUNNING', 'CONFIGURING', 'COMPLETING', 'SUSPENDED', 'REQUEUED', 'RESIZING'}
TERMINAL = {'COMPLETED', 'CANCELLED', 'FAILED', 'TIMEOUT', 'OUT_OF_MEMORY', 'NODE_FAIL', 'PREEMPTED', 'BOOT_FAIL', 'DEADLINE'}


def code_inventory(package):
    base = Path(package).resolve()
    return {p.relative_to(base).as_posix(): sha_file(p)
            for p in sorted((base / 'paper3r13').rglob('*.py')) if '__pycache__' not in p.parts}


def prepare(m12_plan, output, *, package=None, python=None, role='pilot', m12_package=None,
            partition='hpc_gpu1', cpus=12, memory='64G', gpus=1, time_limit='5-03:00:00',
            account=None, config=None):
    emit('R13_PREPARE_START', numerical_imports=False, previous_rounds_changed=False)
    package = Path(package or Path(__file__).resolve().parents[1]).resolve()
    native = importlib.import_module('paper3r13.native')
    inputs = native.prepare_inputs(m12_plan, m12_package=m12_package, role=role)
    output = Path(output).expanduser().resolve()
    old = Path(inputs['m12_plan_path']).resolve().parent
    project_root = Path(inputs['root']).resolve()
    if output == old or output.is_relative_to(old) or project_root == output or project_root.is_relative_to(output):
        raise ValueError('R13 output must be separate from the running M12 directory and project root')
    if output.is_dir() and not (output / 'plan.json').exists():
        existing_names = {entry.name for entry in output.iterdir()}
        if existing_names - {'prepare.lock'}:
            raise ValueError('Output already contains unrelated files; preserve it and choose a new R13 directory')
    if cpus < 1 or gpus != 1:
        raise ValueError('This release runs one persistent worker on one GPU; cpus must be positive')
    if not re.fullmatch('[A-Za-z0-9_.-]+', partition) or not re.fullmatch('[0-9]+[KMGTP]?', memory):
        raise ValueError('Invalid partition or memory resource text')
    people = inputs['participants']
    if isinstance(people, dict):
        people = people.get(role, people.get('meta_validation' if role == 'development' else role, []))
    people = sorted(str(p) for p in people)
    seeds = list(inputs.get('source_seeds', DEFAULT_CONFIG['source_seeds']))
    if not people:
        raise ValueError('No declared participants for this exploratory role')
    tasks = []
    native_role = 'meta_validation' if role == 'development' else role
    for person in people:
        if not re.fullmatch('[A-Za-z0-9_.-]+', person) or person in ('.', '..'):
            raise ValueError('Unsafe participant ID')
        for seed in seeds:
            for generator in (0, 1):
                for amplitude in (.05, .15):
                    key = 'p%s-s%s-g%d-a%s' % (person, seed, generator, str(amplitude).replace('.', 'p'))
                    tasks.append(dict(key=key, participant=person, seed=int(seed), generator=generator,
                                      amplitude=amplitude, role=native_role))
    plan = dict(schema_version=SCHEMA, created_utc=utc(), study='paper3-r13-update-validity',
        root=str(Path(inputs['root']).resolve()), output=str(output), package=str(package),
        python=str(Path(python or DEFAULT_PYTHON).expanduser().absolute()),
        m12_plan_path=str(inputs['m12_plan_path']), m12_package=str(inputs['m12_package']),
        input_identity=inputs['input_identity'], native_inputs=inputs,
        config=copy.deepcopy(DEFAULT_CONFIG if config is None else config),
        resources=dict(partition=partition, cpus=cpus, memory=memory, gpus=gpus,
                       nodes=1, time_limit=time_limit, account=account),
        code_manifest=code_inventory(package), tasks=tasks, original_rounds_modified=False)
    plan['recipe_sha256'] = digest(recipe_payload(plan))
    output.mkdir(parents=True, exist_ok=True)
    with lock(output / 'prepare.lock'):
        path = output / 'plan.json'
        existing = read_json(path)
        if existing is not None:
            if existing.get('recipe_sha256') != plan['recipe_sha256']:
                raise ValueError('Existing R13 plan has a different identity; preserve it and choose a new output')
            plan = load_plan(path)
        else:
            atomic_json(path, plan)
    emit('R13_PLAN_READY', plan=str(path), tasks=len(tasks), participants=len(people),
         scope=plan['config'].get('scope'), scientific_fits_started=0, slurm_calls=0)
    return plan


def _run(command, timeout=15):
    return subprocess.run(command, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                          timeout=timeout, check=False)


def _marker(plan):
    return 'paper3r13-' + plan['recipe_sha256'][:16]


def _known_job_state(job_id, run=_run):
    try:
        value = run(['scontrol', 'show', 'job', '-o', str(job_id)], timeout=10)
        found = re.search(r'\bJobState=([A-Z_]+)', value.stdout)
        if value.returncode == 0 and found:
            return found.group(1)
        value = run(['sacct', '-n', '-X', '-j', str(job_id), '--format=JobIDRaw,State', '--parsable2'], timeout=10)
        for line in value.stdout.splitlines():
            fields = line.split('|')
            if len(fields) > 1 and fields[0].strip() == str(job_id):
                return fields[1].strip().split()[0].split('+')[0]
    except (OSError, subprocess.TimeoutExpired):
        pass
    return 'UNKNOWN'


def _find_marker(plan, run=_run):
    try:
        user = str(os.getuid())
        value = run(['squeue', '-h', '-u', user, '-o', '%i|%k'], timeout=10)
        if value.returncode != 0:
            return None
        found = []
        for line in value.stdout.splitlines():
            fields = line.split('|', 1)
            if len(fields) == 2 and fields[1].strip() == _marker(plan) and re.fullmatch(r'[0-9]+', fields[0].strip()):
                found.append(fields[0].strip())
        return found
    except (OSError, subprocess.TimeoutExpired):
        return None


def submit(plan_path, *, resume=False, run=_run):
    plan_path = Path(plan_path).resolve()
    plan = load_plan(plan_path)
    output = Path(plan['output']); runtime = output / 'runtime'; runtime.mkdir(exist_ok=True)
    if plan['tasks'] and all(scientific_receipt(plan, task) for task in plan['tasks']):
        result = dict(status='STUDY_ALREADY_COMPLETE', complete_tasks=len(plan['tasks']), new_submissions=0)
        emit('R13_SUBMISSION_RESULT', **result)
        return result
    with lock(runtime / 'submit.lock'):
        history = read_json(runtime / 'submission.json', {}) or {}
        job = history.get('job_id')
        intent = read_json(runtime / 'submit-intent.json')
        if intent and intent.get('status') == 'SUBMITTING':
            candidates = _find_marker(plan, run)
            if candidates and len(candidates) == 1:
                recovered = dict(status='ACKNOWLEDGED', job_id=candidates[0], recovered=True,
                                 recipe_sha256=plan['recipe_sha256'], updated_utc=utc())
                atomic_json(runtime / 'submission.json', recovered)
                atomic_json(runtime / 'submit-intent.json', recovered)
                emit('R13_SUBMISSION_RESULT', **recovered, new_submissions=0)
                return recovered
            raise RuntimeError('Previous submit acknowledgement is uncertain. No duplicate submitted; inspect squeue for comment ' + _marker(plan))
        if job:
            state = _known_job_state(job, run)
            if state in LIVE or state == 'UNKNOWN':
                result = dict(status='EXISTING_JOB_PRESERVED', job_id=job, slurm_state=state,
                              new_submissions=0, recipe_sha256=plan['recipe_sha256'])
                emit('R13_SUBMISSION_RESULT', **result)
                return result
            if state not in TERMINAL or not resume:
                result = dict(status='TERMINAL_JOB_USE_SUBMIT_RESUME', job_id=job, slurm_state=state,
                              new_submissions=0)
                emit('R13_SUBMISSION_RESULT', **result)
                return result
        python = Path(plan['python'])
        if not python.is_file() or not os.access(python, os.X_OK):
            raise FileNotFoundError('Prepared school Python is not executable: ' + str(python))
        resources = plan['resources']; logs = output / 'logs'; logs.mkdir(exist_ok=True)
        command = ['sbatch', '--parsable', '--job-name=' + _marker(plan), '--comment=' + _marker(plan),
            '--partition=' + resources['partition'], '--nodes=1', '--ntasks=1',
            '--cpus-per-task=' + str(resources['cpus']), '--mem=' + resources['memory'],
            '--gres=gpu:1', '--time=' + resources['time_limit'], '--signal=B:USR1@120', '--requeue',
            '--output=' + str(logs / 'slurm-%j.out'), '--error=' + str(logs / 'slurm-%j.err'),
            '--chdir=' + plan['root']]
        if resources.get('account'):
            command += ['--account=' + str(resources['account'])]
        command += [str(Path(plan['package']) / 'paper3r13' / 'slurm.sh'), plan['python'], plan['package'], str(plan_path)]
        atomic_json(runtime / 'submit-intent.json', dict(status='SUBMITTING', marker=_marker(plan),
                    previous_job_id=job, recipe_sha256=plan['recipe_sha256'], updated_utc=utc()))
        emit('R13_SUBMITTING', resources=resources, previous_rounds_changed=False)
        try:
            result = run(command, timeout=30)
        except (OSError, subprocess.TimeoutExpired):
            emit('R13_SUBMIT_ACKNOWLEDGEMENT_UNCERTAIN', marker=_marker(plan), duplicate_submitted=False)
            raise
        if result.returncode != 0:
            atomic_json(runtime / 'submit-intent.json', dict(status='REJECTED', updated_utc=utc(),
                         stderr=result.stderr[-6000:], returncode=result.returncode))
            raise RuntimeError('Slurm rejected R13: ' + result.stderr[-6000:])
        match = re.fullmatch(r'\s*([0-9]+)(?:;[^\s]+)?\s*', result.stdout)
        if match is None:
            raise RuntimeError('Slurm submission acknowledgement is not a job ID; preserved intent prevents duplicate submission')
        record = dict(status='ACKNOWLEDGED', job_id=match.group(1), updated_utc=utc(),
                      previous_job_id=job, recipe_sha256=plan['recipe_sha256'])
        atomic_json(runtime / 'submission.json', record)
        atomic_json(runtime / 'submit-intent.json', dict(record, status='ACKNOWLEDGED'))
        emit('R13_SUBMISSION_RESULT', **record, new_submissions=1)
        return record


def status(plan_path, *, queue=True):
    plan = load_plan(plan_path); output = Path(plan['output']); counts = Counter(); errors = []
    for task in plan['tasks']:
        if scientific_receipt(plan, task):
            counts['COMPLETE'] += 1
        else:
            state = safe_read(task_folder(plan, task) / 'state.json', {}) or {}
            phase = state.get('phase', 'WAITING')
            raw_receipt = safe_read(task_folder(plan, task) / 'result.json')
            if isinstance(raw_receipt, dict) and raw_receipt.get('status') == 'COMPLETE' and (
                    raw_receipt.get('recipe_sha256') != plan['recipe_sha256'] or raw_receipt.get('task_key') != task['key']):
                phase = 'ARTIFACT_CONFLICT'
            elif phase == 'COMPLETE':
                phase = 'RECEIPT_MISSING_OR_INCOMPLETE'
            counts[phase] += 1
            if phase == 'ERROR':
                errors.append(dict(task_key=task['key'], error=state.get('error')))
    submission = safe_read(output / 'runtime' / 'submission.json', {}) or {}
    result = dict(recipe_sha256=plan['recipe_sha256'], scope=plan['config'].get('scope'),
                  complete_tasks=counts.get('COMPLETE', 0), total_tasks=len(plan['tasks']),
                  counts=dict(counts), errors=errors, submission=submission,
                  worker=safe_read(output / 'runtime' / 'worker-status.json'), updated_utc=utc())
    if queue and submission.get('job_id'):
        result['slurm_state'] = _known_job_state(submission['job_id'])
    return result


def work(plan_path, *, device='cuda:0', worker=None, stop=None, heartbeat_seconds=30, install_signals=True):
    plan = load_plan(plan_path); output = Path(plan['output']); runtime = output / 'runtime'
    runtime.mkdir(parents=True, exist_ok=True)
    stop = stop or threading.Event(); done = threading.Event()
    if install_signals:
        def request_stop(*_):
            stop.set(); emit('R13_CHECKPOINT_STOP_REQUESTED', pid=os.getpid())
        for sig in (signal.SIGTERM, signal.SIGINT, signal.SIGUSR1):
            signal.signal(sig, request_stop)
    current = dict(phase='STARTING', task_key=None, pid=os.getpid(), device=device,
                   slurm_job_id=os.environ.get('SLURM_JOB_ID'), recipe_sha256=plan['recipe_sha256'])
    mutex = threading.Lock()
    def observe(**fields):
        with mutex:
            current.update(fields); snapshot = dict(current, updated_utc=utc())
        best_effort_json(runtime / 'worker-status.json', snapshot)
        return snapshot
    def heartbeat():
        while not done.wait(heartbeat_seconds):
            snapshot = observe(stop_requested=stop.is_set())
            emit('R13_WORKER_HEARTBEAT', **snapshot)
    try:
        allocation_lock = lock(runtime / 'worker.lock', blocking=False)
        with allocation_lock:
            threading.Thread(target=heartbeat, daemon=True).start()
            emit('R13_WORKER_START', **observe(phase='IMPORTING'), training_started=False)
            # One small package inventory per worker; no full data/source scans per fit.
            for name, expected in plan.get('code_manifest', {}).items():
                if sha_file(Path(plan['package']) / name) != expected:
                    raise ValueError('Prepared R13 package changed: ' + name + '; preserve the plan and use a separate output')
            if worker is None:
                worker = importlib.import_module('paper3r13.worker').run_task
            if stop.is_set():
                return 75
            errors = 0
            for task in plan['tasks']:
                if stop.is_set():
                    break
                folder = task_folder(plan, task); folder.mkdir(parents=True, exist_ok=True)
                if scientific_receipt(plan, task):
                    continue
                # An independent allocation may not own any of our per-task writes.
                with lock(folder / 'task.lock'):
                    if scientific_receipt(plan, task):
                        continue
                    task_state = dict(phase='RUNNING', task_key=task['key'], started_utc=utc(),
                                      recipe_sha256=plan['recipe_sha256'])
                    best_effort_json(folder / 'state.json', task_state)
                    emit('R13_TASK_STARTED', **observe(phase='RUNNING', task_key=task['key']))
                    last_progress = [0.]
                    def progress(**fields):
                        observe(**fields)
                        if time.monotonic() - last_progress[0] >= 10:
                            payload = dict(fields); payload['task_key'] = task['key']
                            emit('R13_TASK_PROGRESS', **payload)
                            last_progress[0] = time.monotonic()
                    try:
                        scientific_receipt(plan, task, strict=True)
                        result = worker(plan, task, device=device, progress=progress, stop=stop)
                        if not isinstance(result, dict):
                            raise ValueError('Scientific worker did not return a receipt')
                        if result.get('status') in ('PAUSED', 'CHECKPOINTED'):
                            best_effort_json(folder / 'state.json', dict(task_state, phase='PAUSED', updated_utc=utc()))
                            stop.set(); break
                        if result.get('status') != 'COMPLETE':
                            raise ValueError('Scientific worker returned an uncompleted result: ' + str(result.get('status')))
                        if result.get('task_key') != task['key'] or result.get('recipe_sha256') != plan['recipe_sha256']:
                            raise ValueError('Scientific receipt identity differs from prepared task')
                        atomic_json(folder / 'result.json', result)
                        best_effort_json(folder / 'state.json', dict(task_state, phase='COMPLETE', updated_utc=utc()))
                        emit('R13_TASK_COMPLETE', task_key=task['key'])
                    except Exception as error:
                        if stop.is_set() and type(error).__name__ in ('PauseRequested', 'StopRequested', 'InterruptedError'):
                            best_effort_json(folder / 'state.json', dict(task_state, phase='PAUSED', updated_utc=utc()))
                            break
                        errors += 1
                        detail = dict(error_type=type(error).__name__, message=str(error)[-4000:])
                        best_effort_json(folder / 'state.json', dict(task_state, phase='ERROR', error=detail, updated_utc=utc()))
                        try:
                            with (folder / 'error.log').open('a') as handle:
                                handle.write('\n' + utc() + '\n' + traceback.format_exc())
                        except OSError:
                            pass
                        emit('R13_TASK_ERROR_OTHER_TASKS_CONTINUE', task_key=task['key'], **detail)
            final = status(plan_path, queue=False)
            if stop.is_set():
                phase, code = 'PAUSED', 75
            elif final['complete_tasks'] == final['total_tasks']:
                phase, code = 'COMPLETE', 0
            else:
                phase, code = 'INCOMPLETE_WITH_ERRORS', 2
            payload = observe(phase=phase); payload.update(complete_tasks=final['complete_tasks'], total_tasks=final['total_tasks'], exit_code=code)
            emit('R13_WORKER_FINISHED', **payload)
            return code
    except BlockingIOError:
        emit('R13_DUPLICATE_WORKER_PRESERVED', new_worker_started=False)
        return 0
    finally:
        done.set()


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__, allow_abbrev=False)
    sub = parser.add_subparsers(dest='command', required=True)
    prep = sub.add_parser('prepare', allow_abbrev=False)
    prep.add_argument('--m12-plan', default=DEFAULT_M12_PLAN)
    prep.add_argument('--m12-package')
    prep.add_argument('--output', default='/public/home/zhuziyuan/projects/paper3/runs/r13_update_validity')
    prep.add_argument('--python', default=DEFAULT_PYTHON)
    prep.add_argument('--role', choices=('pilot', 'development'), default='pilot')
    prep.add_argument('--partition', default='hpc_gpu1'); prep.add_argument('--cpus', type=int, default=12)
    prep.add_argument('--memory', default='64G'); prep.add_argument('--gpus', type=int, default=1)
    prep.add_argument('--time', dest='time_limit', default='5-03:00:00'); prep.add_argument('--account')
    for name in ('submit', 'status', 'work', 'run', 'report'):
        value = sub.add_parser(name, allow_abbrev=False)
        value.add_argument('--plan', required=True)
        if name == 'submit':
            value.add_argument('--resume', action='store_true')
        if name in ('work', 'run'):
            value.add_argument('--device', default='cuda:0')
    args = vars(parser.parse_args(argv)); command = args.pop('command')
    if command == 'prepare':
        plan = prepare(**args); emit('R13_READY', plan=str(Path(plan['output']) / 'plan.json'))
    elif command == 'submit':
        submit(args.pop('plan'), **args)
    elif command == 'status':
        emit('R13_STATUS', **status(args['plan']))
    elif command in ('work', 'run'):
        return work(args.pop('plan'), **args)
    else:
        plan = load_plan(args['plan'])
        report = importlib.import_module('paper3r13.report').generate_report(plan)
        emit('R13_REPORT', **report)
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
