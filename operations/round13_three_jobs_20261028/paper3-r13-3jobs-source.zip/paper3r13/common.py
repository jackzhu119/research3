"""Small durable records; telemetry is best effort and never controls science."""
from __future__ import annotations
from contextlib import contextmanager
import errno
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import tempfile
import time

TRANSIENT = {errno.EINTR, errno.EAGAIN, errno.EBUSY, errno.EIO, errno.ENOENT,
             errno.EEXIST, errno.ETIMEDOUT, getattr(errno, 'ESTALE', 116)}


def utc():
    return time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())


def encoded(value):
    return (json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2,
                       allow_nan=False) + '\n').encode('utf-8')


def digest(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True,
                                    separators=(',', ':'), allow_nan=False).encode()).hexdigest()


def sha_file(path):
    result = hashlib.sha256()
    with Path(path).open('rb') as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b''):
            result.update(block)
    return result.hexdigest()


def read_json(path, default=None, max_bytes=64 * 1024 * 1024):
    try:
        with Path(path).open('rb') as handle:
            size = os.fstat(handle.fileno()).st_size
            if size > max_bytes or size < 0:
                raise ValueError('JSON file exceeds the declared record limit: ' + str(path))
            data = handle.read(size + 1)
        if len(data) != size:
            raise ValueError('JSON changed during reading; preserve it and retry: ' + str(path))
        return json.loads(data)
    except FileNotFoundError:
        return default


def safe_read(path, default=None, max_bytes=64 * 1024 * 1024):
    try:
        return read_json(path, default, max_bytes)
    except (OSError, ValueError, TypeError):
        return default


def atomic_bytes(path, data, *, attempts=7, sleep=time.sleep):
    """Unique same-filesystem staging; never remove a previous destination.

    Retry short shared-filesystem RPC failures, accepting an ambiguous rename
    only when destination bytes exactly match. Unsuccessful durable science
    writes raise; best_effort_json is reserved for operational observations.
    """
    if not isinstance(data, bytes):
        raise TypeError('atomic_bytes requires exact bytes')
    if attempts < 1:
        raise ValueError('attempts must be positive')
    path = Path(path)
    for attempt in range(attempts):
        stage = temporary = None
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            stage = Path(tempfile.mkdtemp(prefix='.r13-write-', dir=path.parent))
            temporary = stage / 'payload'
            with temporary.open('xb') as handle:
                handle.write(data)
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(temporary, path)
            return path
        except OSError as error:
            try:
                if path.is_file() and path.stat().st_size == len(data) and path.read_bytes() == data:
                    return path
            except OSError:
                pass
            if error.errno not in TRANSIENT or attempt + 1 >= attempts:
                raise
            sleep(min(.05 * 2 ** attempt, 1.0))
        finally:
            if temporary is not None:
                try:
                    temporary.unlink(missing_ok=True)
                except OSError:
                    pass
            if stage is not None:
                try:
                    stage.rmdir()
                except OSError:
                    pass


def atomic_json(path, value, **kwargs):
    return atomic_bytes(path, encoded(value), **kwargs)


atomic = atomic_json
sha = sha_file
read = read_json


def best_effort_json(path, value):
    try:
        atomic_json(path, value)
        return True
    except (OSError, ValueError, TypeError):
        return False


def emit(event, **fields):
    try:
        payload = dict(event=event, utc=utc()); payload.update(fields)
        print(json.dumps(payload, ensure_ascii=False,
                         allow_nan=False, default=str), flush=True)
    except (OSError, ValueError, TypeError):
        pass


@contextmanager
def lock(path, blocking=True):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('a') as handle:
        fcntl.flock(handle, fcntl.LOCK_EX | (0 if blocking else fcntl.LOCK_NB))
        try:
            yield handle
        finally:
            fcntl.flock(handle, fcntl.LOCK_UN)


def task_folder(plan, task):
    key = task['key']
    if not isinstance(key, str) or not re.fullmatch('[A-Za-z0-9_.-]+', key) or key in ('.', '..'):
        raise ValueError('Invalid task key')
    return Path(plan['output']) / 'tasks' / key


def recipe_payload(plan):
    return {k: v for k, v in plan.items() if k not in {'recipe_sha256', 'created_utc'}}


def load_plan(path):
    plan = read_json(path)
    if not isinstance(plan, dict) or plan.get('schema_version') != 'paper3-r13-plan-v1':
        raise ValueError('A prepared R13 plan is required')
    if plan.get('recipe_sha256') != digest(recipe_payload(plan)):
        raise ValueError('The R13 plan changed after preparation; use a new output directory')
    return plan


class ScientificArtifactConflict(ValueError):
    """Existing durable scientific content belongs to another identity."""


def scientific_receipt(plan, task, *, strict=False):
    """Read only the small seal and file metadata, never large output hashes."""
    path = task_folder(plan, task) / 'result.json'
    result = read_json(path) if strict else safe_read(path)
    if not isinstance(result, dict) or result.get('status') != 'COMPLETE':
        return None
    if result.get('recipe_sha256') != plan['recipe_sha256'] or result.get('task_key') != task['key']:
        if strict:
            raise ScientificArtifactConflict('Preserving an existing receipt with incompatible identity: ' + str(path))
        return None
    for descriptor in result.get('files', []):
        if not isinstance(descriptor, dict) or 'path' not in descriptor:
            if strict:
                raise ScientificArtifactConflict('Invalid artifact descriptor in existing receipt')
            return None
        target = (Path(plan['output']) / descriptor['path']).resolve()
        if not target.is_relative_to(Path(plan['output']).resolve()):
            if strict:
                raise ScientificArtifactConflict('Artifact escaped the new experiment output')
            return None
        try:
            if not target.is_file() or ('bytes' in descriptor and target.stat().st_size != descriptor['bytes']):
                return None
        except OSError:
            return None
    return result
