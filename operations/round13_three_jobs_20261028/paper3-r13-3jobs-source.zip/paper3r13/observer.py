"""Detached R13 report/status observer with independent, incremental delivery.

This process never imports the scientific worker, opens EEG arrays, asks Slurm
for resources or controls training. Public delivery is a narrow allowlist of
sealed derived outputs; original EEG and revealed/evaluation labels stay local.
"""
from __future__ import annotations
from contextlib import contextmanager
import hashlib
import importlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import threading
import time

from .common import (atomic_json, best_effort_json, digest, emit, encoded, load_plan,
                     lock, read_json, safe_read, sha_file, utc)

PREFIX = 'results/paper3/round-13/studies'
REPOSITORY = 'jackzhu119/research3'
BRANCH = 'paper3-results'
BINARY_PART_BYTES = 8 * 1024 * 1024
PAPER_FILES = ('report.json', 'participant_metrics.csv')
FULL_NAMES = {'receipt.json', 'metrics.csv', 'prediction-seal.json', 'predictions.npz', 'decisions.json'}
FORBIDDEN_PARTS = {'.git', '.ssh', 'private', 'secrets', 'credentials', '__pycache__'}


def _runtime(plan):
    return Path(plan['output']) / 'runtime'


def _signature(path):
    value = path.stat()
    return [value.st_dev, value.st_ino, value.st_size, value.st_mtime_ns, value.st_ctime_ns]


def _safe_file(plan, path):
    output = Path(plan['output']).resolve()
    path = Path(path)
    if path.is_symlink() or not path.is_file() or not path.resolve().is_relative_to(output):
        raise ValueError('Independent public artifact escaped the R13 output')
    relative = path.relative_to(output)
    if any(part in FORBIDDEN_PARTS or part.startswith('.') for part in relative.parts):
        raise ValueError('Private or temporary output refused')
    if path.name not in FULL_NAMES | set(PAPER_FILES):
        raise ValueError('Output is not in the public scientific allowlist')
    return relative.as_posix()


def _transport(plan):
    """Reuse the already installed M12's binary-safe CAS transport, once."""
    package = Path(plan['m12_package']).resolve()
    if not (package / 'paper3m12/uploads.py').is_file():
        raise FileNotFoundError('Installed M12 public transport is unavailable')
    existing = sys.modules.get('paper3m12')
    if existing is not None and not Path(existing.__file__).resolve().is_relative_to(package):
        raise ValueError('Another installed M12 package is already loaded')
    if str(package) not in sys.path:
        sys.path.insert(0, str(package))
    return importlib.import_module('paper3m12.uploads')


def _client(plan, transport):
    work = _runtime(plan) / 'observer-upload'
    work.mkdir(parents=True, exist_ok=True)
    # Token discovery returns only to GitHubClient and is never serialized.
    token = transport.discover_token(plan.get('github_credentials'))
    return transport.GitHubClient(token, repo=REPOSITORY, branch=BRANCH,
                                  cache_path=work / 'verified-blobs.jsonl', timeout=90)


def _public_plan(plan):
    allowed = ('schema_version', 'study', 'recipe_sha256', 'config', 'tasks',
               'resources', 'input_identity', 'code_manifest', 'original_rounds_modified')
    return {key: plan[key] for key in allowed if key in plan}


def _public_status(plan, observation, observer_state):
    worker = observation.get('worker') or {}
    if not isinstance(worker, dict):
        worker = {}
    submission = observation.get('submission') or {}
    if not isinstance(submission, dict):
        submission = {}
    return dict(schema_version='paper3-r13-public-status-v1', round=13,
        recipe_sha256=plan['recipe_sha256'], updated_utc=utc(),
        complete_tasks=observation.get('complete_tasks', 0), total_tasks=len(plan.get('tasks', [])),
        counts=observation.get('counts', {}), scope=plan['config'].get('scope'),
        independent_confirmation=False,
        worker={key: worker.get(key) for key in ('phase','task_key','stage','session','fit','step',
            'total_steps','sessions_complete','sessions_expected','conditions_complete','conditions_total',
            'budget','updated_utc','pid','slurm_job_id')},
        submission={key: submission.get(key) for key in ('status','job_id','job_ids','updated_utc')},
        errors=[dict(task_key=row.get('task_key'), error_type=(row.get('error') or {}).get('error_type'))
                for row in observation.get('errors', []) if isinstance(row, dict)],
        uploads={key: observer_state.get(key) for key in ('paper_files_verified', 'full_files_verified',
                 'full_sessions_verified', 'last_success_utc', 'status', 'report_status', 'report_error_type')},
        parallel_slots=observation.get('slots',[]) if observation.get('parallel') else [],
        parallel=bool(observation.get('parallel')),
        training_controlled=False, completion_claimed_by_observer=False)


def _session_files(plan, proofs=None):
    """Read only declared completed session seals; never archive a directory."""
    output = Path(plan['output']).resolve()
    proofs = proofs or {}
    for task in plan.get('tasks', []):
        root = output / 'tasks' / task['key'] / 'sessions'
        for receipt_path in sorted(root.glob('*/receipt.json')):
            _safe_file(plan, receipt_path)
            receipt = read_json(receipt_path, {}, max_bytes=4 * 1024 * 1024)
            if (not isinstance(receipt, dict) or receipt.get('status') != 'COMPLETE'
                    or receipt.get('task_key') != task['key']
                    or receipt.get('recipe_sha256') != plan['recipe_sha256']):
                continue
            sources = [receipt_path]
            files = receipt.get('files', {})
            descriptors = files.values() if isinstance(files, dict) else files
            for descriptor in descriptors:
                if not isinstance(descriptor, dict) or not isinstance(descriptor.get('path'), str):
                    continue
                path = output / descriptor['path']
                if path.name not in FULL_NAMES or path == receipt_path:
                    continue
                relative = _safe_file(plan, path)
                # A malicious/corrupt receipt cannot point into another task's tree.
                if not path.resolve().is_relative_to(receipt_path.parent.resolve()):
                    raise ValueError('Public session artifact belongs to another session')
                if descriptor.get('bytes') is not None and path.stat().st_size != descriptor['bytes']:
                    raise ValueError('Sealed public artifact byte count differs')
                cached = proofs.get('full:' + relative, {})
                if descriptor.get('sha256') and not (
                        cached.get('signature') == _signature(path)
                        and cached.get('original_sha256') == descriptor['sha256']
                        and cached.get('remote_GET_SHA256_verified')):
                    if sha_file(path) != descriptor['sha256']:
                        raise ValueError('Sealed public artifact checksum differs; original retained')
                sources.append(path)
            yield receipt_path.parent.relative_to(output).as_posix(), list(dict.fromkeys(sources))


def _upload_path(plan, client, transport, path, channel, proofs):
    relative = _safe_file(plan, path)
    signature = _signature(path)
    proof_key = channel + ':' + relative
    previous = proofs.get(proof_key, {})
    if previous.get('signature') == signature and previous.get('remote_GET_SHA256_verified'):
        return False
    prefix = PREFIX + '/' + plan['recipe_sha256'][:16] + '/' + channel + '/' + relative
    entries, manifest = transport.upload_file(client, prefix, path,
        csv_chunk_bytes=BINARY_PART_BYTES, binary_chunk_bytes=BINARY_PART_BYTES)
    if not manifest.get('remote_complete_blob_GET_SHA256_verified'):
        raise ValueError('Complete remote blob GET verification is missing')
    commit = client.publish(entries, 'Archive R13 ' + channel + ' derived artifact ' + relative)
    proofs[proof_key] = dict(signature=signature, original_sha256=manifest['original_sha256'],
        original_bytes=manifest['original_bytes'], manifest_path=prefix + '/manifest.json',
        commit=commit, remote_GET_SHA256_verified=True)
    atomic_json(_runtime(plan) / 'observer-upload' / 'file-proofs.json',
                dict(recipe_sha256=plan['recipe_sha256'], files=proofs))
    return True


def run_once(plan_path, *, client=None, transport=None, report=True, full=True,
             max_full_files=4, status_fn=None, report_fn=None):
    """One resumable observer pass. Failures never touch fitting state."""
    plan = load_plan(plan_path) if not isinstance(plan_path, dict) else plan_path
    runtime = _runtime(plan); runtime.mkdir(parents=True, exist_ok=True)
    state_path = runtime / 'observer-status.json'
    previous = safe_read(state_path, {}) or {}
    state = dict(schema_version='paper3-r13-observer-v1', recipe_sha256=plan['recipe_sha256'],
                 pid=os.getpid(), plan_path=str(Path(plan['output']) / 'plan.json'),
                 status='OBSERVING', last_success_utc=previous.get('last_success_utc'),
                 training_controlled=False, updated_utc=utc())
    proof_path = runtime / 'observer-upload' / 'file-proofs.json'
    old_proofs = safe_read(proof_path, {}) or {}
    proofs = old_proofs.get('files', {}) if old_proofs.get('recipe_sha256') == plan['recipe_sha256'] else {}
    if not isinstance(proofs, dict):
        proofs = {}
    try:
        if status_fn is None:
            from .runtime import status
            status_fn = lambda path: status(path, queue=False)
        observation = status_fn(Path(plan['output']) / 'plan.json')
        best_effort_json(runtime / 'observer-local-status.json',
                         _public_status(plan, observation, previous))
        # A report error is isolated from status delivery and all training work.
        if report:
            try:
                if report_fn is None:
                    from .report import generate_report
                    report_fn = generate_report
                report_fn(plan)
                state['report_status'] = 'READY'
            except Exception as error:
                state['report_status'] = 'RETRYING'
                state['report_error_type'] = type(error).__name__
                emit('R13_REPORT_OBSERVER_RETRY', error_type=type(error).__name__, training_controlled=False)
        transport = transport or _transport(plan)
        client = client or _client(plan, transport)
        prefix = PREFIX + '/' + plan['recipe_sha256'][:16]
        entries = {prefix + '/paper/plan.json': client.blob(encoded(_public_plan(plan)))}
        # Publish small status before any larger file or full-scientific backlog.
        snapshot = _public_status(plan, observation, previous)
        entries[prefix + '/status.json'] = client.blob(encoded(snapshot))
        client.publish(entries, 'Update R13 independent progress')
        for name in PAPER_FILES:
            path = Path(plan['output']) / name
            if path.is_file():
                _upload_path(plan, client, transport, path, 'paper', proofs)
        state['paper_files_verified'] = sum(key.startswith('paper:') for key in proofs)
        state['status'] = 'PAPER_VERIFIED'
        state['updated_utc'] = utc()
        best_effort_json(state_path, state)
        budget = max(0, int(max_full_files)); uploaded = 0; sessions_verified = 0
        if full:
            for session, sources in _session_files(plan, proofs):
                for path in sources:
                    relative = _safe_file(plan, path)
                    cached = proofs.get('full:' + relative, {})
                    if cached.get('signature') == _signature(path) and cached.get('remote_GET_SHA256_verified'):
                        continue
                    if uploaded >= budget:
                        break
                    _upload_path(plan, client, transport, path, 'full', proofs)
                    uploaded += 1
                if all(proofs.get('full:' + _safe_file(plan, p), {}).get('signature') == _signature(p)
                       and proofs.get('full:' + _safe_file(plan, p), {}).get('remote_GET_SHA256_verified')
                       for p in sources):
                    sessions_verified += 1
        state.update(status='OBSERVING', full_files_verified=sum(key.startswith('full:') for key in proofs),
                     full_sessions_verified=sessions_verified, full_files_uploaded_this_pass=uploaded,
                     last_success_utc=utc(), updated_utc=utc())
        pointer = dict(schema_version='paper3-r13-public-artifact-pointer-v1', round=13,
            recipe_sha256=plan['recipe_sha256'], channel='PUBLIC_DERIVED_ARTIFACTS',
            complete_tasks=observation.get('complete_tasks',0), total_tasks=len(plan['tasks']),
            paper_files_verified=state['paper_files_verified'], full_files_verified=state['full_files_verified'],
            full_sessions_verified=sessions_verified, updated_utc=utc(),
            scope='Allowlisted derived outputs only; raw EEG and all input/evaluation labels remain local',
            remote_complete_blob_GET_SHA256_verified=True, scientific_completion_claimed=False,
            training_controlled=False,
            files={key: {k: v for k,v in value.items() if k != 'signature'} for key,value in proofs.items()})
        public_status = _public_status(plan, observation, state)
        commit = client.publish({prefix + '/ARTIFACTS_LATEST.json': client.blob(encoded(pointer)),
                                 prefix + '/status.json': client.blob(encoded(public_status))},
                                'Update R13 independent artifact coverage')
        state['commit'] = commit
        best_effort_json(state_path, state)
        emit('R13_OBSERVER_PASS', status=state['status'], paper_files_verified=state['paper_files_verified'],
             full_files_verified=state['full_files_verified'], training_controlled=False)
        return state
    except Exception as error:
        state.update(status='RETRYING', error_type=type(error).__name__,
                     http_status=getattr(error,'status',None), updated_utc=utc(),
                     paper_files_verified=sum(key.startswith('paper:') for key in proofs),
                     full_files_verified=sum(key.startswith('full:') for key in proofs))
        best_effort_json(state_path,state)
        emit('R13_OBSERVER_RETRY', error_type=state['error_type'], http_status=state['http_status'], training_controlled=False)
        return state


def _matches_pid(pid, plan_path):
    try:
        pid = int(pid)
        if pid <= 1:
            return False
        os.kill(pid, 0)
        args = Path('/proc/%d/cmdline' % pid).read_bytes().split(b'\0')
        return b'observer' in args and os.fsencode(str(Path(plan_path).resolve())) in args
    except (OSError, ValueError, TypeError):
        return False


def start(plan_path, *, interval=180, full=True):
    """Start a detached singleton; closing the terminal does not stop it."""
    plan_path = Path(plan_path).resolve(); plan = load_plan(plan_path)
    runtime = _runtime(plan); runtime.mkdir(parents=True, exist_ok=True)
    with lock(runtime / 'observer-start.lock'):
        process = safe_read(runtime / 'observer-process.json', {}) or {}
        if _matches_pid(process.get('pid'),plan_path):
            result = dict(status='EXISTING_OBSERVER_PRESERVED', pid=process['pid'], new_processes=0,
                          terminal_can_close=True)
            emit('R13_OBSERVER_START', **result); return result
        try:
            with lock(runtime / 'observer.lock', blocking=False):
                pass
        except BlockingIOError:
            result = dict(status='EXISTING_OBSERVER_LOCK_PRESERVED', new_processes=0, terminal_can_close=True)
            emit('R13_OBSERVER_START', **result); return result
        command = [plan['python'], '-I','-S','-B','-u',
                   str(Path(plan['package'])/'paper3r13/bootstrap.py'), 'observer',
                   '--plan',str(plan_path),'--interval',str(max(30,int(interval)))]
        if not full:
            command.append('--paper-only')
        with (runtime/'observer.log').open('ab',buffering=0) as log, open(os.devnull,'rb') as null:
            child = subprocess.Popen(command,stdin=null,stdout=log,stderr=log,start_new_session=True,
                                     close_fds=True,cwd=plan['root'])
        record = dict(status='STARTED',pid=child.pid,plan_path=str(plan_path),updated_utc=utc(),
                      interval_seconds=max(30,int(interval)),full_public_artifacts=full,
                      training_controlled=False,terminal_can_close=True)
        atomic_json(runtime/'observer-process.json',record)
        emit('R13_OBSERVER_START',**record,new_processes=1)
        return record


def loop(plan_path, *, interval=180, full=True, stop=None):
    plan = load_plan(plan_path); stop = stop or threading.Event()
    if threading.current_thread() is threading.main_thread():
        for number in (signal.SIGTERM,signal.SIGINT):
            signal.signal(number,lambda *_:stop.set())
    try:
        with lock(_runtime(plan)/'observer.lock',blocking=False):
            emit('R13_OBSERVER_READY',pid=os.getpid(),training_controlled=False)
            # A failed network attempt never ends the loop or touches workers.
            while not stop.is_set():
                run_once(plan_path,full=full)
                stop.wait(max(30,int(interval)))
    except BlockingIOError:
        emit('R13_OBSERVER_ALREADY_RUNNING',training_controlled=False)
    return 0


def main(argv=None):
    import argparse
    parser=argparse.ArgumentParser(description=__doc__,allow_abbrev=False)
    parser.add_argument('--plan',required=True)
    parser.add_argument('--interval',type=int,default=180)
    parser.add_argument('--paper-only',action='store_true')
    args=parser.parse_args(argv)
    return loop(args.plan,interval=args.interval,full=not args.paper_only)
