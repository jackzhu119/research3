"""Three one-GPU R13 allocations around the original immutable scientific plan.

This module is an operational controller.  It never changes the scientific
recipe, source packages, checkpoints or completed receipts.  A legacy job is
replaced only after an identity-bound PENDING hold/recheck/cancel transaction.
"""
from __future__ import annotations

import argparse
from collections import Counter
from contextlib import contextmanager
import fcntl
import importlib
import importlib.util
import os
from pathlib import Path
import re
import shlex
import signal
import subprocess
import sys
import threading
import time
import traceback

from .common import (atomic_json, best_effort_json, digest, emit, load_plan, lock,
                     read_json, safe_read, scientific_receipt, sha_file, task_folder, utc)
from . import runtime

SEEDS = (20261018, 20261019, 20261020)
SCHEMA = 'paper3-r13-three-worker-launch-v1'
CONTROL_FILES = ('paper3r13/parallel.py', 'paper3r13/bootstrap.py', 'paper3r13/parallel_slurm.sh')


def _directory(plan):
    return Path(plan['output']) / 'runtime' / 'parallel'


def _slot_marker(plan, slot):
    return 'paper3r13p-' + plan['recipe_sha256'][:12] + '-s' + str(slot)


def shard_tasks(plan, slot):
    if slot not in range(3):
        raise ValueError('R13 parallel slot must be0,1 or2')
    keys = [task['key'] for task in plan['tasks']]
    if len(keys) != len(set(keys)) or {int(task['seed']) for task in plan['tasks']} != set(SEEDS):
        raise ValueError('Three-shard launch requires the exact original three source seeds and unique tasks')
    return [task for task in plan['tasks'] if int(task['seed']) == SEEDS[slot]]


def _verify_original(plan):
    package=Path(plan['package']).resolve()
    if not (package/'paper3r13/worker.py').is_file():
        raise FileNotFoundError('Original immutable R13 scientific package is missing')
    for name,expected in plan.get('code_manifest', {}).items():
        source=(package/name).resolve()
        if not source.is_relative_to(package) or not source.is_file() or sha_file(source)!=expected:
            raise ValueError('Original scientific package changed; preserving all checkpoints: '+name)


def _launch_payload(value):
    return {k:v for k,v in value.items() if k not in ('created_utc','launch_identity')}


def prepare_launch(plan_path, *, package=None):
    plan_path=Path(plan_path).resolve();plan=load_plan(plan_path)
    _verify_original(plan)
    package=Path(package or Path(__file__).resolve().parents[1]).resolve()
    script=package/'paper3r13/parallel_slurm.sh'
    if not script.is_file() or not os.access(script,os.X_OK):
        raise FileNotFoundError('New three-worker Slurm script is not ready: '+str(script))
    shards=[shard_tasks(plan,slot) for slot in range(3)]
    if not all(shards) or sum(map(len,shards))!=len(plan['tasks']):
        raise ValueError('Parallel task coverage is incomplete')
    resources=dict(partition='hpc_gpu1',cpus=12,memory='64G',gpus=1,nodes=1,
                   time_limit=plan['resources']['time_limit'],account=plan['resources'].get('account'))
    launch=dict(schema_version=SCHEMA,created_utc=utc(),plan_path=str(plan_path),
        recipe_sha256=plan['recipe_sha256'],scientific_package=plan['package'],
        controller_package=str(package),resources=resources,
        slots=[dict(slot=slot,source_seed=SEEDS[slot],task_keys=[t['key'] for t in tasks],
                    marker=_slot_marker(plan,slot)) for slot,tasks in enumerate(shards)],
        control_manifest={name:sha_file(package/name) for name in CONTROL_FILES},
        scientific_plan_changed=False,scientific_state_changed=False)
    launch['launch_identity']=digest(_launch_payload(launch))
    directory=_directory(plan);directory.mkdir(parents=True,exist_ok=True)
    with lock(directory/'prepare.lock'):
        path=directory/'launch.json';existing=read_json(path)
        if existing is not None:
            if (existing.get('launch_identity')!=digest(_launch_payload(existing))
                    or existing['launch_identity']!=launch['launch_identity']):
                raise ValueError('Existing parallel launch has a different control identity; no jobs changed')
            launch=existing
        else:
            atomic_json(path,launch)
    return launch


def _load_launch(plan):
    value=read_json(_directory(plan)/'launch.json')
    if (not isinstance(value,dict) or value.get('schema_version')!=SCHEMA
            or value.get('recipe_sha256')!=plan['recipe_sha256']
            or value.get('launch_identity')!=digest(_launch_payload(value))):
        raise ValueError('Prepared three-worker launch identity is missing or changed')
    return value


def _fields(line):
    matches=list(re.finditer(r'(?<!\S)([A-Za-z][A-Za-z0-9_:]*)=',line))
    return {m.group(1):line[m.end():matches[i+1].start() if i+1<len(matches) else len(line)].strip()
            for i,m in enumerate(matches)}


def _job(job_id,run):
    value=run(['scontrol','show','job','-o',str(job_id)],timeout=10)
    return _fields(value.stdout) if value.returncode==0 else None


def _validate_legacy(plan,job_id,details):
    if details is None:
        raise ValueError('Legacy job identity could not be read; no cancellation performed')
    uid=re.fullmatch(r'.*\(([0-9]+)\)',details.get('UserId',''))
    expected=[str(Path(plan['package'])/'paper3r13/slurm.sh'),plan['python'],plan['package'],
              str(Path(plan['output'])/'plan.json')]
    try:
        command=shlex.split(details.get('Command',''))
    except ValueError:
        command=[]
    if (details.get('JobId')!=str(job_id) or uid is None or int(uid.group(1))!=os.getuid()
            or details.get('Comment')!=runtime._marker(plan)
            or details.get('JobName')!=runtime._marker(plan)
            or command!=expected or Path(details.get('WorkDir','/')).resolve()!=Path(plan['root']).resolve()
            or details.get('Partition')!=plan['resources']['partition']
            or details.get('NumCPUs')!=str(plan['resources']['cpus'])
            or details.get('MinMemoryNode')!=plan['resources']['memory']
            or details.get('TresPerNode') not in ('gpu:1','gres/gpu:1')):
        raise ValueError('Legacy job does not match this exact R13 launch; no cancellation performed')


def _pending_unallocated(details):
    return (details.get('JobState')=='PENDING'
        and details.get('NodeList') in ('(null)','(none)','None','')
        and details.get('BatchHost','(null)') in ('(null)','(none)','None',''))


def _retire_legacy(plan,run):
    directory=_directory(plan);path=directory/'legacy-replacement.json'
    previous=read_json(path,{}) or {}
    history=read_json(Path(plan['output'])/'runtime/submission.json',{}) or {}
    intent=read_json(Path(plan['output'])/'runtime/submit-intent.json',{}) or {}
    job=previous.get('job_id') or history.get('job_id')
    if not job and intent.get('status')=='SUBMITTING':
        found=runtime._find_marker(plan,run)
        if found is not None and len(found)==1:
            job=found[0]
        else:
            return dict(status='LEGACY_SUBMISSION_UNCERTAIN',new_submissions=0)
    if not job:
        result=dict(status='NO_LEGACY_ALLOCATION',job_id=None,updated_utc=utc())
        atomic_json(path,result);return result
    if not re.fullmatch('[0-9]+',str(job)):
        raise ValueError('Legacy submission record has an invalid job ID')
    details=_job(job,run)
    state=details.get('JobState') if details else runtime._known_job_state(job,run)
    if state in runtime.TERMINAL:
        result=dict(status='LEGACY_TERMINAL',job_id=str(job),slurm_state=state,updated_utc=utc())
        atomic_json(path,result);return result
    if state not in ('PENDING',):
        return dict(status='LEGACY_RUNNING_PRESERVED' if state in runtime.LIVE else 'LEGACY_STATE_UNCERTAIN',
                    job_id=str(job),slurm_state=state,new_submissions=0)
    _validate_legacy(plan,job,details)
    if not _pending_unallocated(details):
        return dict(status='LEGACY_ALLOCATION_PRESERVED',job_id=str(job),new_submissions=0)
    if previous.get('status') in ('CANCEL_SENT','CANCEL_UNCERTAIN'):
        return dict(status='WAITING_FOR_LEGACY_CANCEL',job_id=str(job),new_submissions=0)
    held=run(['scontrol','hold',str(job)],timeout=10)
    if held.returncode!=0:
        return dict(status='LEGACY_HOLD_NOT_ACKNOWLEDGED',job_id=str(job),new_submissions=0)
    details=_job(job,run)
    try:
        _validate_legacy(plan,job,details)
        if not _pending_unallocated(details):
            run(['scontrol','release',str(job)],timeout=10)
            return dict(status='LEGACY_STARTED_PRESERVED',job_id=str(job),new_submissions=0)
        atomic_json(path,dict(status='HELD_PENDING_VERIFIED',job_id=str(job),updated_utc=utc()))
        try:
            cancelled=run(['scancel',str(job)],timeout=10)
        except (OSError,subprocess.TimeoutExpired):
            atomic_json(path,dict(status='CANCEL_UNCERTAIN',job_id=str(job),updated_utc=utc()))
            return dict(status='WAITING_FOR_LEGACY_CANCEL',job_id=str(job),new_submissions=0)
        final=_job(job,run)
        state=final.get('JobState') if final else runtime._known_job_state(job,run)
        if cancelled.returncode!=0 and state not in runtime.TERMINAL:
            # A rejected cancellation must not strand the old pending job in
            # a permanent hold.  No replacement was submitted; restore its
            # eligibility and permit an explicit later retry of this command.
            run(['scontrol','release',str(job)],timeout=10)
            atomic_json(path,dict(status='CANCEL_REJECTED_RETRYABLE',job_id=str(job),
                returncode=cancelled.returncode,updated_utc=utc()))
            return dict(status='LEGACY_CANCEL_REJECTED_RETRYABLE',job_id=str(job),new_submissions=0)
        atomic_json(path,dict(status='CANCEL_SENT',job_id=str(job),returncode=cancelled.returncode,updated_utc=utc()))
        if state not in runtime.TERMINAL:
            return dict(status='WAITING_FOR_LEGACY_CANCEL',job_id=str(job),new_submissions=0)
        result=dict(status='LEGACY_PENDING_REPLACED',job_id=str(job),slurm_state=state,updated_utc=utc())
        atomic_json(path,result);return result
    except Exception:
        # We held only a verified own R13 pending job; restore it on any failed
        # post-hold validation, never touch an executing scientific process.
        try:run(['scontrol','release',str(job)],timeout=10)
        except Exception:pass
        raise


def _find_slot(plan,slot,run):
    result=run(['squeue','-h','-u',str(os.getuid()),'-o','%i|%k'],timeout=10)
    if result.returncode!=0:return None
    found=[]
    for line in result.stdout.splitlines():
        parts=line.split('|',1)
        if len(parts)==2 and parts[1].strip()==_slot_marker(plan,slot) and re.fullmatch('[0-9]+',parts[0].strip()):
            found.append(parts[0].strip())
    return found


def _submit_slot(plan,launch,slot,run):
    directory=_directory(plan);path=directory/('slot-%d.json'%slot)
    tasks=shard_tasks(plan,slot)
    if all(scientific_receipt(plan,t) for t in tasks):
        return dict(slot=slot,status='SCIENTIFIC_SHARD_COMPLETE',new_submissions=0)
    record=read_json(path,{}) or {}
    if record.get('status')=='SUBMITTING':
        found=_find_slot(plan,slot,run)
        if found and len(found)==1:
            record=dict(slot=slot,status='ACKNOWLEDGED',job_id=found[0],recovered=True,updated_utc=utc())
            atomic_json(path,record);return dict(record,new_submissions=0)
        return dict(slot=slot,status='SUBMISSION_ACKNOWLEDGEMENT_UNCERTAIN',new_submissions=0)
    old=record.get('job_id')
    if old:
        state=runtime._known_job_state(old,run)
        if state in runtime.LIVE or state=='UNKNOWN':
            return dict(slot=slot,status='EXISTING_JOB_PRESERVED',job_id=old,slurm_state=state,new_submissions=0)
    resource=launch['resources'];package=launch['controller_package'];logs=Path(plan['output'])/'logs'
    logs.mkdir(parents=True,exist_ok=True)
    marker=_slot_marker(plan,slot)
    command=['sbatch','--parsable','--job-name='+marker,'--comment='+marker,
        '--partition='+resource['partition'],'--nodes=1','--ntasks=1','--cpus-per-task=12',
        '--mem=64G','--gres=gpu:1','--time='+resource['time_limit'],'--signal=B:USR1@120','--requeue',
        '--output='+str(logs/('parallel-slot%d-%%j.out'%slot)),
        '--error='+str(logs/('parallel-slot%d-%%j.err'%slot)),'--chdir='+plan['root']]
    if resource.get('account'):command+=['--account='+resource['account']]
    command += [str(Path(package)/'paper3r13/parallel_slurm.sh'),plan['python'],package,launch['plan_path'],str(slot)]
    atomic_json(path,dict(slot=slot,status='SUBMITTING',previous_job_id=old,marker=marker,updated_utc=utc()))
    try:
        result=run(command,timeout=30)
    except (OSError,subprocess.TimeoutExpired):
        return dict(slot=slot,status='SUBMISSION_ACKNOWLEDGEMENT_UNCERTAIN',new_submissions=0)
    if result.returncode!=0:
        record=dict(slot=slot,status='REJECTED',returncode=result.returncode,
                    scheduler_message=result.stderr[-4000:],updated_utc=utc())
        atomic_json(path,record);return dict(record,new_submissions=0)
    match=re.fullmatch(r'\s*([0-9]+)(?:;[^\s]+)?\s*',result.stdout)
    if match is None:
        return dict(slot=slot,status='SUBMISSION_ACKNOWLEDGEMENT_UNCERTAIN',new_submissions=0)
    record=dict(slot=slot,status='ACKNOWLEDGED',job_id=match.group(1),previous_job_id=old,
                marker=marker,source_seed=SEEDS[slot],updated_utc=utc())
    atomic_json(path,record);return dict(record,new_submissions=1)


def submit(plan_path, *, package=None, run=runtime._run):
    plan_path=Path(plan_path).resolve();plan=load_plan(plan_path)
    launch=prepare_launch(plan_path,package=package)
    # This is the same file locked EX by the legacy single worker.  Holding it
    # only over replacement makes the mutation atomic w.r.t. its startup.
    with lock(_directory(plan)/'submit.lock'):
        retired=read_json(_directory(plan)/'legacy-replacement.json',{}) or {}
        original=read_json(Path(plan['output'])/'runtime/submission.json',{}) or {}
        retired_states={'NO_LEGACY_ALLOCATION','LEGACY_TERMINAL','LEGACY_PENDING_REPLACED'}
        reconciled=(retired.get('status') in retired_states
                    and retired.get('job_id')==original.get('job_id'))
        if reconciled:
            retirement=retired
        else:
            try:
                with lock(Path(plan['output'])/'runtime/worker.lock',blocking=False):
                    retirement=_retire_legacy(plan,run)
            except BlockingIOError:
                return dict(status='LEGACY_WORKER_ALREADY_RUNNING_PRESERVED',slots=[],new_submissions=0)
        if retirement['status'] not in retired_states:
            return dict(status=retirement['status'],legacy=retirement,slots=[],new_submissions=0)
        # Existing parallel workers may already hold the shared legacy guard.
        # Their presence must not block reconciliation of another empty slot.
        slots=[_submit_slot(plan,launch,slot,run) for slot in range(3)]
    result=dict(status='THREE_WORKER_LAUNCH_RECONCILED',legacy=retirement,slots=slots,
        new_submissions=sum(s.get('new_submissions',0) for s in slots),
        requested_jobs=3,gpus_per_job=1,cpus_per_job=12,memory_per_job='64G',
        scientific_recipe_unchanged=True,updated_utc=utc())
    atomic_json(_directory(plan)/'last-submit.json',result)
    emit('R13_PARALLEL_SUBMISSION',**result)
    return result


def _load_original_worker(plan):
    _verify_original(plan)
    alias='_paper3r13_science_'+plan['recipe_sha256'][:16]
    if alias not in sys.modules:
        source=Path(plan['package'])/'paper3r13'
        spec=importlib.util.spec_from_file_location(alias,source/'__init__.py',submodule_search_locations=[str(source)])
        module=importlib.util.module_from_spec(spec);sys.modules[alias]=module;spec.loader.exec_module(module)
    return importlib.import_module(alias+'.worker').run_task


@contextmanager
def _legacy_shared_lock(plan):
    path=Path(plan['output'])/'runtime/worker.lock';path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('a') as handle:
        fcntl.flock(handle,fcntl.LOCK_SH|fcntl.LOCK_NB)
        try:yield
        finally:fcntl.flock(handle,fcntl.LOCK_UN)


def work(plan_path,slot,*,device='cuda:0',worker=None,stop=None,heartbeat_seconds=30,install_signals=True):
    plan=load_plan(plan_path);launch=_load_launch(plan);slot=int(slot);tasks=shard_tasks(plan,slot)
    package=Path(launch['controller_package'])
    for name,expected in launch['control_manifest'].items():
        if sha_file(package/name)!=expected:raise ValueError('Parallel controller changed after preparation: '+name)
    directory=_directory(plan);stop=stop or threading.Event();done=threading.Event();mutex=threading.Lock()
    current=dict(slot=slot,source_seed=SEEDS[slot],phase='STARTING',task_key=None,pid=os.getpid(),
        device=device,slurm_job_id=os.environ.get('SLURM_JOB_ID'),recipe_sha256=plan['recipe_sha256'])
    if install_signals:
        def request_stop(*_):stop.set();emit('R13_PARALLEL_CHECKPOINT_REQUESTED',slot=slot)
        for number in (signal.SIGTERM,signal.SIGINT,signal.SIGUSR1):signal.signal(number,request_stop)
    def observe(**fields):
        with mutex:current.update(fields);snapshot=dict(current,updated_utc=utc())
        best_effort_json(directory/('worker-slot-%d.json'%slot),snapshot)
        return snapshot
    def heartbeat():
        while not done.wait(heartbeat_seconds):emit('R13_PARALLEL_HEARTBEAT',**observe(stop_requested=stop.is_set()))
    try:
        with _legacy_shared_lock(plan),lock(directory/('worker-slot-%d.lock'%slot),blocking=False):
            threading.Thread(target=heartbeat,daemon=True).start()
            emit('R13_PARALLEL_WORKER_START',**observe(phase='IMPORTING',shard_tasks=len(tasks)))
            if worker is None:worker=_load_original_worker(plan)
            for task in tasks:
                if stop.is_set():break
                folder=task_folder(plan,task);folder.mkdir(parents=True,exist_ok=True)
                if scientific_receipt(plan,task):continue
                with lock(folder/'task.lock'):
                    if scientific_receipt(plan,task):continue
                    state=dict(phase='RUNNING',slot=slot,task_key=task['key'],recipe_sha256=plan['recipe_sha256'],started_utc=utc())
                    best_effort_json(folder/'state.json',state)
                    emit('R13_PARALLEL_TASK_START',**observe(phase='RUNNING',task_key=task['key']))
                    last=[0.]
                    def progress(**fields):
                        observe(**fields)
                        if time.monotonic()-last[0]>=10:
                            emit('R13_PARALLEL_PROGRESS',slot=slot,**fields);last[0]=time.monotonic()
                    try:
                        scientific_receipt(plan,task,strict=True)
                        result=worker(plan,task,device=device,progress=progress,stop=stop)
                        if isinstance(result,dict) and result.get('status') in ('PAUSED','CHECKPOINTED'):
                            best_effort_json(folder/'state.json',dict(state,phase='PAUSED',updated_utc=utc()));stop.set();break
                        if (not isinstance(result,dict) or result.get('status')!='COMPLETE'
                                or result.get('task_key')!=task['key'] or result.get('recipe_sha256')!=plan['recipe_sha256']):
                            raise ValueError('Scientific worker did not return this original task receipt')
                        atomic_json(folder/'result.json',result)
                        best_effort_json(folder/'state.json',dict(state,phase='COMPLETE',updated_utc=utc()))
                    except Exception as error:
                        if stop.is_set() and isinstance(error,InterruptedError):break
                        detail=dict(error_type=type(error).__name__,message=str(error)[-4000:])
                        best_effort_json(folder/'state.json',dict(state,phase='ERROR',error=detail,updated_utc=utc()))
                        try:
                            with (folder/'error.log').open('a') as handle:handle.write('\n'+utc()+'\n'+traceback.format_exc())
                        except OSError:pass
                        emit('R13_PARALLEL_TASK_ERROR_OTHER_TASKS_CONTINUE',slot=slot,task_key=task['key'],**detail)
            complete=sum(bool(scientific_receipt(plan,t)) for t in tasks)
            phase,code=('PAUSED',75) if stop.is_set() else ('COMPLETE',0) if complete==len(tasks) else ('INCOMPLETE_WITH_ERRORS',2)
            emit('R13_PARALLEL_WORKER_FINISHED',**observe(phase=phase,complete_tasks=complete,total_tasks=len(tasks),exit_code=code))
            return code
    except BlockingIOError:
        emit('R13_PARALLEL_EXISTING_WORKER_PRESERVED',slot=slot,new_scientific_worker_started=False)
        return 0
    finally:done.set()


def status(plan_path,*,queue=True,run=runtime._run):
    plan=load_plan(plan_path);result=runtime.status(plan_path,queue=False);slots=[]
    for slot in range(3):
        record=read_json(_directory(plan)/('slot-%d.json'%slot),{}) or {}
        tasks=shard_tasks(plan,slot)
        snapshot=dict(slot=slot,source_seed=SEEDS[slot],complete_tasks=sum(bool(scientific_receipt(plan,t)) for t in tasks),
            total_tasks=len(tasks),submission=record,worker=safe_read(_directory(plan)/('worker-slot-%d.json'%slot)))
        if queue and record.get('job_id'):snapshot['slurm_state']=runtime._known_job_state(record['job_id'],run)
        slots.append(snapshot)
    legacy=result.get('submission',{})
    jobs=[s['submission']['job_id'] for s in slots if s['submission'].get('job_id')]
    states={s.get('slurm_state') for s in slots}
    phase=('COMPLETE' if result['complete_tasks']==result['total_tasks'] else
           'RUNNING' if 'RUNNING' in states else 'PENDING' if 'PENDING' in states else
           'CONFIGURING' if 'CONFIGURING' in states else 'UNKNOWN' if jobs else 'NOT_SUBMITTED')
    result.update(parallel=True,slots=slots,resources_per_job=dict(gpus=1,cpus=12,memory='64G'),requested_jobs=3,
        legacy_submission=legacy,submission=dict(status='THREE_WORKER_LAUNCH',job_ids=jobs,updated_utc=utc()),
        worker=dict(phase=phase,updated_utc=utc(),parallel_workers=3))
    return result


def main(argv=None):
    parser=argparse.ArgumentParser(allow_abbrev=False);parser.add_argument('command',choices=('work','status','submit'))
    parser.add_argument('--plan',required=True);parser.add_argument('--slot',type=int);parser.add_argument('--device',default='cuda:0')
    args=parser.parse_args(argv)
    if args.command=='work':return work(args.plan,args.slot,device=args.device)
    if args.command=='submit':emit('R13_PARALLEL_SUBMISSION',**submit(args.plan));return 0
    emit('R13_PARALLEL_STATUS',**status(args.plan));return 0
