#!/bin/bash
# Bash4.2 and Slurm20 compatible. Resource flags belong to the submit command.
set -eu
R13_PY="$1"
R13_PACKAGE="$2"
R13_PLAN="$3"
export PYTHONUNBUFFERED=1
export PYTHONDONTWRITEBYTECODE=1
export OMP_NUM_THREADS=1
export OPENBLAS_NUM_THREADS=1
export MKL_NUM_THREADS=1
export NUMEXPR_NUM_THREADS=1
export R13_CPU_THREADS="${SLURM_CPUS_PER_TASK:-12}"
export CUBLAS_WORKSPACE_CONFIG=:4096:8
exec "$R13_PY" -I -S -B -u "$R13_PACKAGE/paper3r13/bootstrap.py" work --plan "$R13_PLAN" --device cuda:0
