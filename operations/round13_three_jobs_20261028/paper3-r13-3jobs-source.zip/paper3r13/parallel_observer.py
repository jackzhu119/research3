"""Detached report/upload observer for the three-job operational control layer.

The original scientific plan is read-only.  Only a verified legacy observer
may receive SIGTERM; GPU workers and scheduler jobs are never controlled here.
Waiting for an old network request to finish happens in this background helper,
never in a GPU allocation or the user's submission command.
"""
from __future__ import annotations

import os
from pathlib import Path
import signal
import subprocess
import threading

from .common import atomic_json, best_effort_json, emit, load_plan, lock, safe_read, utc


def _runtime(plan):
    return Path(plan['output']) / 'runtime'


def _control(plan):
    return _runtime(plan) / 'parallel'


def _process_snapshot(pid, *, proc_root=Path('/proc')):
    """Return only process identity; never inspect environment or secrets."""
    try:
        pid = int(pid)
        if pid <= 1:
            return None
        process = Path(proc_root) / str(pid)
        owner = process.stat().st_uid
        args = process.joinpath('cmdline').read_bytes().split(b'\0')
        args = tuple(arg for arg in args if arg)
        stat = process.joinpath('stat').read_text()
        # comm may contain spaces or parentheses. Fields after its last ')' start
        # with field3; starttime is field22, hence index19 in the remaining list.
        rest = stat[stat.rfind(')')+2:].split()
        if len(rest) < 20:
            return None
        return dict(pid=pid, uid=owner, args=args, start_time=rest[19])
    except (OSError, ValueError, TypeError, OverflowError):
        return None


def _matches(snapshot, plan_path, package, command):
    if not isinstance(snapshot, dict) or snapshot.get('uid') != os.geteuid():
        return False
    args = list(snapshot.get('args', ()))
    bootstrap = os.fsencode(str(Path(package).resolve() / 'paper3r13/bootstrap.py'))
    expected_plan = os.fsencode(str(Path(plan_path).resolve()))
    try:
        at = args.index(bootstrap)
        if args[at+1] != command.encode('ascii'):
            return False
        tail = args[at+2:]
        if tail.count(b'--plan') != 1:
            return False
        where = tail.index(b'--plan')
        return tail[where+1] == expected_plan
    except (ValueError, IndexError, UnicodeError):
        return False


def _request_legacy_stop(plan, plan_path, *, probe=None, send_signal=None):
    """Gracefully stop only the old plan-bound observer, never a worker PID."""
    record = safe_read(_runtime(plan) / 'observer-process.json', {}) or {}
    pid = record.get('pid')
    if pid is None:
        return dict(status='NO_LEGACY_OBSERVER_RECORD', signalled=False)
    recorded_path = record.get('plan_path')
    if recorded_path and Path(recorded_path).resolve() != Path(plan_path).resolve():
        return dict(status='LEGACY_RECORD_IDENTITY_UNCONFIRMED', signalled=False)
    probe = _process_snapshot if probe is None else probe
    send_signal = os.kill if send_signal is None else send_signal
    first = probe(pid)
    if not _matches(first, plan_path, plan['package'], 'observer'):
        return dict(status='LEGACY_PROCESS_IDENTITY_UNCONFIRMED', signalled=False)
    # Check start time, owner and command again immediately before signalling.
    second = probe(pid)
    if first != second or not _matches(second, plan_path, plan['package'], 'observer'):
        return dict(status='LEGACY_PROCESS_IDENTITY_CHANGED', signalled=False)
    try:
        send_signal(int(pid), signal.SIGTERM)
        return dict(status='LEGACY_OBSERVER_GRACEFUL_STOP_REQUESTED', pid=int(pid),
                    signalled=True, scientific_processes_signalled=0)
    except ProcessLookupError:
        return dict(status='LEGACY_OBSERVER_ALREADY_EXITED', signalled=False)
    except (OSError, ValueError, TypeError):
        return dict(status='LEGACY_OBSERVER_STOP_NOT_ACKNOWLEDGED', signalled=False)


def start(plan_path, *, package=None, interval=180, full=True):
    """Start immediately; the detached helper performs any monitor handover."""
    plan_path = Path(plan_path).resolve()
    plan = load_plan(plan_path)
    package = Path(package or Path(__file__).resolve().parents[1]).resolve()
    bootstrap = package / 'paper3r13/bootstrap.py'
    if not bootstrap.is_file():
        raise FileNotFoundError('New parallel observer bootstrap is unavailable')
    control = _control(plan)
    control.mkdir(parents=True, exist_ok=True)
    with lock(control / 'observer-start.lock'):
        record = safe_read(control / 'observer-process.json', {}) or {}
        if _matches(_process_snapshot(record.get('pid')), plan_path, package, 'parallel-observer'):
            result = dict(status='EXISTING_PARALLEL_OBSERVER_PRESERVED', pid=record['pid'],
                          new_processes=0, terminal_can_close=True, training_controlled=False)
            emit('R13_PARALLEL_OBSERVER_START', **result)
            return result
        try:
            with lock(control / 'observer-worker.lock', blocking=False):
                pass
        except BlockingIOError:
            result = dict(status='EXISTING_PARALLEL_OBSERVER_LOCK_PRESERVED', new_processes=0,
                          terminal_can_close=True, training_controlled=False)
            emit('R13_PARALLEL_OBSERVER_START', **result)
            return result
        command = [plan['python'], '-I', '-S', '-B', '-u', str(bootstrap),
                   'parallel-observer', '--plan', str(plan_path),
                   '--interval', str(max(30, int(interval)))]
        if not full:
            command.append('--paper-only')
        with (control / 'observer.log').open('ab', buffering=0) as log, open(os.devnull, 'rb') as null:
            child = subprocess.Popen(command, stdin=null, stdout=log, stderr=log,
                                     start_new_session=True, close_fds=True, cwd=plan['root'])
        record = dict(status='OBSERVER_START_REQUESTED', pid=child.pid, plan_path=str(plan_path),
                      package=str(package), interval_seconds=max(30, int(interval)),
                      full_public_artifacts=bool(full), ready=False,
                      readiness_scope='Detached helper started; shared observer lock handover is pending',
                      training_controlled=False, terminal_can_close=True, updated_utc=utc())
        atomic_json(control / 'observer-process.json', record)
        emit('R13_PARALLEL_OBSERVER_START', **record, new_processes=1)
        return record


def loop(plan_path, *, interval=180, full=True, stop=None, run_once=None,
         status_fn=None, wait_seconds=5):
    plan_path = Path(plan_path).resolve()
    plan = load_plan(plan_path)
    control = _control(plan)
    control.mkdir(parents=True, exist_ok=True)
    stop = stop or threading.Event()
    if threading.current_thread() is threading.main_thread():
        for number in (signal.SIGTERM, signal.SIGINT):
            signal.signal(number, lambda *_: stop.set())
    state_path = control / 'observer-status.json'
    try:
        with lock(control / 'observer-worker.lock', blocking=False):
            handover = _request_legacy_stop(plan, plan_path)
            best_effort_json(control / 'observer-handover.json', dict(handover, updated_utc=utc()))
            while not stop.is_set():
                try:
                    with lock(_runtime(plan) / 'observer.lock', blocking=False):
                        if run_once is None:
                            from .observer import run_once as observer_pass
                        else:
                            observer_pass = run_once
                        if status_fn is None:
                            from .parallel import status as parallel_status
                            observe = lambda path: parallel_status(path, queue=True)
                        else:
                            observe = status_fn
                        emit('R13_PARALLEL_OBSERVER_READY', pid=os.getpid(), training_controlled=False)
                        while not stop.is_set():
                            try:
                                result = observer_pass(plan_path, full=full, status_fn=observe)
                                phase = result.get('status', 'OBSERVING') if isinstance(result, dict) else 'OBSERVING'
                                best_effort_json(state_path, dict(status=phase, ready=True, pid=os.getpid(),
                                    training_controlled=False, updated_utc=utc()))
                            except Exception as error:
                                # Includes status/report/network failures. No scientific file is touched.
                                best_effort_json(state_path, dict(status='RETRYING', ready=True,
                                    error_type=type(error).__name__, training_controlled=False, updated_utc=utc()))
                                emit('R13_PARALLEL_OBSERVER_RETRY', error_type=type(error).__name__,
                                     training_controlled=False)
                            stop.wait(max(30, int(interval)))
                        return 0
                except BlockingIOError:
                    best_effort_json(state_path, dict(status='WAITING_FOR_LEGACY_OBSERVER_LOCK',
                        ready=False, pid=os.getpid(), training_controlled=False,
                        handover=handover['status'], updated_utc=utc()))
                    emit('R13_PARALLEL_OBSERVER_HANDOVER_WAIT', training_controlled=False,
                         scientific_workers_waiting=False)
                    stop.wait(max(.1, float(wait_seconds)))
            return 0
    except BlockingIOError:
        emit('R13_PARALLEL_OBSERVER_ALREADY_RUNNING', training_controlled=False)
        return 0


def main(argv=None):
    import argparse
    parser = argparse.ArgumentParser(description=__doc__, allow_abbrev=False)
    parser.add_argument('--plan', required=True)
    parser.add_argument('--interval', type=int, default=180)
    parser.add_argument('--paper-only', action='store_true')
    args = parser.parse_args(argv)
    return loop(args.plan, interval=args.interval, full=not args.paper_only)
