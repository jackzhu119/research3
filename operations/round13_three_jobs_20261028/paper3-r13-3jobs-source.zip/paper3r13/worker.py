"""Durable participant/seed/perturbation blocks; future labels follow prediction seals.

Each real session has two initial fits and four same-label-budget refits.
Worlds, interpolation levels and decision baselines reuse those actual fits.
Only this new study's output is written. No network or scheduler calls occur.
"""
from __future__ import annotations

from dataclasses import is_dataclass, replace
import copy
import csv
import hashlib
import io
from pathlib import Path
import time
import traceback
from types import SimpleNamespace

import numpy as np
import torch

from . import algorithm as alg
from .common import (atomic_bytes, atomic_json, best_effort_json, digest, emit,
                     read_json, sha_file, task_folder, utc)
from .native import Bridge

_BRIDGES = {}
_RHOS = (0., .25, .5, .75, 1.)


def _notice(callback, **fields):
    if callback is not None:
        try:
            callback(**fields)
        except Exception:
            pass


def _stopped(stop):
    return bool(stop is not None and (stop.is_set() if hasattr(stop, 'is_set') else stop()))


def _check_stop(stop):
    if _stopped(stop):
        raise InterruptedError('Requested checkpoint pause; complete fits remain saved')


def _bridge(plan, device):
    key = (plan['recipe_sha256'], str(device))
    if key not in _BRIDGES:
        _BRIDGES.clear()  # A worker owns exactly one prepared study.
        _BRIDGES[key] = Bridge(plan, device)
    return _BRIDGES[key]


def _np(value):
    return value.detach().cpu().numpy() if isinstance(value, torch.Tensor) else np.asarray(value)


def _tensor_sha(value):
    array = np.ascontiguousarray(_np(value))
    h = hashlib.sha256(str((array.shape, str(array.dtype))).encode())
    h.update(array.tobytes())
    return h.hexdigest()


def _changed(support, x):
    if is_dataclass(support):
        return replace(support, x=x)
    return SimpleNamespace(**dict(vars(support), x=x))


def _descriptor(path, output):
    path, output = Path(path).resolve(), Path(output).resolve()
    if not path.is_relative_to(output) or path.is_symlink() or not path.is_file():
        raise ValueError('New scientific artifact escaped the declared R13 output')
    return dict(path=path.relative_to(output).as_posix(), bytes=path.stat().st_size,
                sha256=sha_file(path))


def _verify_descriptor(output, descriptor):
    path = (Path(output) / descriptor['path']).resolve()
    if (not path.is_relative_to(Path(output).resolve()) or not path.is_file()
            or path.stat().st_size != descriptor['bytes'] or sha_file(path) != descriptor['sha256']):
        raise ValueError('Saved R13 scientific artifact changed; preserving existing files')
    return path


def metrics(labels, probabilities):
    labels = np.asarray(_np(labels))
    p = np.asarray(probabilities, dtype=np.float64)
    if (labels.ndim != 1 or p.shape != (len(labels), 2) or not len(labels)
            or not np.isin(labels, (0, 1)).all() or not np.isfinite(p).all()
            or (p < 0).any() or (p > 1).any() or not np.allclose(p.sum(1), 1., atol=1e-7, rtol=0)):
        raise ValueError('Prediction/label shape or finite probability contract failed')
    labels = labels.astype(np.int64)
    losses = -np.log(np.clip(p[np.arange(len(labels)), labels], 1e-12, 1.))
    both = bool((labels == 0).any() and (labels == 1).any())
    decisions = p[:, 1] >= .5
    ba = .5 * sum(float((decisions[labels == c] == c).mean()) for c in (0, 1)) if both else None
    nll = .5 * sum(float(losses[labels == c].mean()) for c in (0, 1)) if both else None
    return dict(BA=ba, balanced_NLL=nll, Brier=float(((p[:, 1] - labels)**2).mean()),
                evaluation_status='OK' if both else 'UNDEFINED_BALANCED_METRIC_SINGLE_CLASS',
                query_trials=len(labels))


def _fit(plan, task, session, folder, name, model, support_x, support_y, reference,
         *, kind='spatial', budget=12, progress=None, stop=None, reuse=None):
    identity = dict(recipe=plan['recipe_sha256'], task=task['key'], session=session.identity,
        fit=name, kind=kind, acquired_budget=budget, model=getattr(model, 'identity', {}),
        support_x=_tensor_sha(support_x), support_y=_tensor_sha(support_y),
        algorithm=alg.ALGORITHM_VERSION, optimizer=plan['config'].get('optimizer', {}))
    fingerprint = digest(identity)
    final_path = folder / 'fits' / (name + '.json')
    previous = read_json(final_path)
    if previous is not None:
        if previous.get('identity') != identity or previous.get('fit_identity') != fingerprint:
            raise ValueError('Existing fit belongs to another input/algorithm identity: ' + name)
        return previous['state'], fingerprint, dict(reused_r13=True, fitted_now=False)
    raw_path = folder / 'fits' / (name + '-raw.json')
    saved = read_json(raw_path, {}) or {}
    if saved and saved.get('fit_identity') != fingerprint:
        raise ValueError('Unfinished raw checkpoint identity differs: ' + name)
    raw = saved.get('raw_cache', {})
    def checkpoint(key, state):
        raw[key] = state
        atomic_json(raw_path, dict(fit_identity=fingerprint, raw_cache=raw, updated_utc=utc()))
    config = copy.deepcopy(plan['config'])
    config['episode_identity'] = identity
    if reuse is not None:
        state, proof = ((reuse['state'], reuse['proof']) if isinstance(reuse, dict) else reuse)
        state = copy.deepcopy(state)
        state.update(kind=kind, source_seed=task['seed'], acquired_budget=budget,
                     query_used_for_fitting=False, algorithm_version=alg.ALGORITHM_VERSION,
                     reused_existing_m12=True)
        provenance = dict(reused_m12=True, fitted_now=False, proof=proof)
    else:
        _check_stop(stop)
        _notice(progress, stage='fit_start', session=session.session_id, fit=name, budget=budget)
        try:
            state = alg.fit(model, support_x, support_y, reference['x'], kind=kind,
                seed=task['seed'], budget=budget, config=config, raw_cache=raw,
                checkpoint=checkpoint, progress=progress, stop=stop)
        except alg.FitPaused as error:
            raise InterruptedError(str(error)) from error
        provenance = dict(fitted_now=True, resumed_raw=bool(saved))
    atomic_json(final_path, dict(identity=identity, fit_identity=fingerprint, state=state,
                                provenance=provenance, completed_utc=utc()))
    return state, fingerprint, provenance


def _shrink_choice(model, fitted, sentinel_x, sentinel_y):
    labels = np.asarray(_np(sentinel_y), dtype=np.int64)
    if not len(labels) or not ((labels == 0).any() and (labels == 1).any()):
        return 0., 'INSUFFICIENT_SENTINEL_CLASSES'
    candidates = []
    for factor in (0., .5, 1.):
        score = metrics(labels, alg.predict(model, alg.scale_state(fitted, factor), sentinel_x))
        candidates.append((score['balanced_NLL'], factor))
    return min(candidates)[1], 'SENTINEL_ONLY_FIXED_GRID'


def _session(plan, task, session, bridge, folder, *, progress=None, stop=None):
    output = Path(plan['output'])
    base_identity = dict(recipe_sha256=plan['recipe_sha256'], task_key=task['key'],
                         session_identity=session.identity)
    receipt_path = folder / 'receipt.json'
    receipt = read_json(receipt_path)
    if receipt is not None:
        if receipt.get('status') != 'COMPLETE' or any(receipt.get(k) != v for k, v in base_identity.items()):
            raise ValueError('Existing session receipt identity differs')
        # Only this session's small metrics and seal are checked on restart.
        _verify_descriptor(output, receipt['files']['metrics'])
        _verify_descriptor(output, receipt['files']['prediction_seal'])
        for proof in receipt['files'].values():
            path=(output/proof['path']).resolve()
            if (not path.is_relative_to(output.resolve()) or not path.is_file()
                    or path.is_symlink() or path.stat().st_size != proof['bytes']):
                raise ValueError('Completed session has a missing/changed scientific artifact; preserving files')
        return receipt
    folder.mkdir(parents=True, exist_ok=True)
    seal_path = folder / 'prediction-seal.json'
    seal = read_json(seal_path)
    if seal is None:
        initial = bridge.initial(session)
        if (tuple(initial.acquired_event_uids) != tuple(session.audit['acquired_prefix_uids'][:12])
                or len(initial.acquired_event_uids) != 12 or len(set(initial.acquired_event_uids)) != 12
                or not set(initial.event_uids).issubset(set(initial.acquired_event_uids))):
            raise ValueError('Initial support must charge exactly12 original acquired positions')
        generator, amplitude, seed = task['generator'], task['amplitude'], task['seed']
        sx = bridge.transform(initial.x, generator, amplitude, 1., seed=seed)
        support = _changed(initial, sx)
        model = bridge.model(seed, support)
        reference = bridge.reference(seed)
        anchor = alg.anchor_state(model)
        fit_states, fit_ids, fit_provenance = {}, {}, {}
        for kind in ('spatial', 'full_head'):
            reuse = None
            if kind == 'spatial' and hasattr(bridge, 'reuse_initial'):
                reuse = bridge.reuse_initial(session, seed, generator, amplitude,
                                             getattr(model, 'identity', {}), plan['config'])
            state, fit_id, provenance = _fit(plan, task, session, folder, 'initial-' + kind,
                model, sx, support.y, reference, kind=kind, progress=progress, stop=stop, reuse=reuse)
            fit_states[kind], fit_ids[kind], fit_provenance[kind] = state, fit_id, provenance
        specs = []
        def add(kind, rho, method, state, *, k=0, info='prefix_only', fit_identity=None,
                inference_model=None, valid_sentinel=0, decision=None):
            specs.append(dict(model=kind, rho=float(rho), method=method, state=state,
                k=k, information=info, initial_fit_identity=fit_ids[kind],
                selected_fit_identity=fit_identity or fit_ids[kind], valid_sentinel=valid_sentinel,
                decision=decision, inference_model=inference_model or model,
                stage='mechanism' if k == 0 else 'observation_cost'))
        for kind in ('spatial', 'full_head'):
            for rho in _RHOS:
                add(kind, rho, 'EA_B12', anchor)
                add(kind, rho, 'retain_initial', fit_states[kind])
        fitted = fit_states['spatial']
        support_predictions = dict(EA=alg.predict(model, anchor, sx), adapt=alg.predict(model, fitted, sx))
        sentinel_audit = []
        for rho in (0., 1.):
            for k in (4, 8):
                _check_stop(stop)
                view = bridge.sentinel_inputs(session, k)
                expected_acquired = tuple(session.audit['acquired_prefix_uids'][12:12+k])
                if (tuple(view.acquired_event_uids) != expected_acquired
                        or not set(view.event_uids).issubset(set(view.acquired_event_uids))
                        or set(view.event_uids) & set(initial.acquired_event_uids)
                        or set(view.event_uids) & set(session.audit['query_uids'])):
                    raise ValueError('Later observations overlap or replace fixed acquired positions')
                later_x = bridge.transform(view.x, generator, amplitude, rho, seed=seed)
                preds = dict(EA=alg.predict(model, anchor, later_x), adapt=alg.predict(model, fitted, later_x))
                x_decisions = alg.decide(support_predictions, preds, support.y,
                    support_x=sx, sentinel_x=later_x, config=plan['config'])
                combined_x = torch.cat((sx, later_x), dim=0)
                all_uids = tuple(support.event_uids) + tuple(view.event_uids)
                all_acquired = tuple(support.acquired_event_uids) + tuple(view.acquired_event_uids)
                updated_ea = bridge.ea_model(seed, combined_x, all_uids, all_acquired)
                for info in ('sentinel_X_only', 'sentinel_XY'):
                    for method, state in (('EA_B12', anchor), ('retain_initial', fitted)):
                        add('spatial', rho, method, state, k=k, info=info, valid_sentinel=len(view.event_uids))
                    add('spatial', rho, 'updated_EA', alg.anchor_state(updated_ea), k=k, info=info,
                        inference_model=updated_ea, valid_sentinel=len(view.event_uids))
                for method in ('candidate_X', 'generic_shift_X', 'consistency_X'):
                    decision = x_decisions[method]
                    add('spatial', rho, method, alg.scale_state(fitted, decision['factor']), k=k,
                        info='sentinel_X_only', valid_sentinel=len(view.event_uids), decision=decision)
                # Only the XY path reveals these later labels. No query labels exist here.
                later_y = bridge.reveal_sentinel_labels(session, k)
                xy_decisions = alg.decide(support_predictions, preds, support.y, later_y,
                    support_x=sx, sentinel_x=later_x, config=plan['config'])
                for method in ('candidate_XY', 'holdout_XY'):
                    decision = xy_decisions[method]
                    add('spatial', rho, method, alg.scale_state(fitted, decision['factor']), k=k,
                        info='sentinel_XY', valid_sentinel=len(view.event_uids), decision=decision)
                factor, reason = _shrink_choice(model, fitted, later_x, later_y)
                add('spatial', rho, 'shrink_XY', alg.scale_state(fitted, factor), k=k,
                    info='sentinel_XY', valid_sentinel=len(view.event_uids), decision=dict(factor=factor, reason=reason))
                combined_y = torch.cat((support.y, later_y), dim=0)
                state, refit_id, provenance = _fit(plan, task, session, folder,
                    'refit-rho%s-B%d' % (str(rho).replace('.', 'p'), 12+k), updated_ea,
                    combined_x, combined_y, reference, budget=12+k, progress=progress, stop=stop)
                fit_provenance['refit-rho%s-k%d' % (rho,k)] = provenance
                add('spatial', rho, 'refit_all_labels', state, k=k, info='sentinel_XY',
                    valid_sentinel=len(view.event_uids), fit_identity=refit_id, inference_model=updated_ea)
                sentinel_audit.append(dict(rho=rho, k=k, acquired_uids=list(view.acquired_event_uids),
                    valid_uids=list(view.event_uids), invalid_positions_charged=k-len(view.event_uids)))
        if len(specs) != 72:
            raise ValueError('Internal scientific branch coverage differs from72 prespecified method rows')
        # Freeze all fit/decision specifications before opening any final-query input.
        metadata = []
        for spec in specs:
            metadata.append({k:v for k,v in spec.items() if k != 'inference_model'})
        decisions = dict(**base_identity, initial_acquired_uids=list(initial.acquired_event_uids),
            initial_valid_uids=list(initial.event_uids), sentinel_audit=sentinel_audit,
            methods=metadata, fit_provenance=fit_provenance, query_labels_read=False)
        atomic_json(folder / 'decisions.json', decisions)
        _check_stop(stop)
        query = bridge.query_inputs(session)
        if (tuple(query.event_uids) != tuple(session.audit['query_uids'])
                or set(query.event_uids) & set(session.audit['acquired_prefix_uids'])):
            raise ValueError('Final query UID/order contract differs across the worlds')
        query_signature = digest(list(query.event_uids))
        values = []
        # Reuse branch inputs and predictions for identical model/state fingerprints.
        branch_inputs, predictions_cache = {}, {}
        for index,spec in enumerate(specs):
            _check_stop(stop)
            rho = spec['rho']
            if rho not in branch_inputs:
                branch_inputs[rho] = bridge.transform(query.x, generator, amplitude, rho, seed=seed)
            infer = spec['inference_model']
            key = digest(dict(rho=rho, model=getattr(infer,'identity',{}), state=spec['state']))
            if key not in predictions_cache:
                predictions_cache[key] = alg.predict(infer, spec['state'], branch_inputs[rho])
            values.append(predictions_cache[key])
            _notice(progress, stage='query_prediction', session=session.session_id,
                    conditions_complete=index+1, conditions_total=len(specs))
        probabilities = np.stack(values)
        buffer = io.BytesIO()
        # Keep the native evaluator's Nx2 anchor capability while sealing all
        # branch predictions in the same immutable archive before labels.
        np.savez_compressed(buffer, probabilities=probabilities[0], all_probabilities=probabilities,
            event_uids=np.asarray(query.event_uids,dtype=np.str_),
            session_identity=np.asarray(session.identity), recipe_sha256=np.asarray(plan['recipe_sha256']))
        atomic_bytes(folder / 'predictions.npz', buffer.getvalue())
        seal = dict(**base_identity, status='PREDICTIONS_SEALED', query_signature=query_signature,
            conditions=len(specs), valid_support=len(initial.event_uids),
            predictions=_descriptor(folder / 'predictions.npz', output),
            decisions=_descriptor(folder / 'decisions.json', output), created_utc=utc())
        atomic_json(seal_path, seal)
    else:
        if any(seal.get(k) != v for k,v in base_identity.items()) or seal.get('conditions') != 72:
            raise ValueError('Prediction seal belongs to a different scientific session')
    pred_path = _verify_descriptor(output, seal['predictions'])
    decisions_path = _verify_descriptor(output, seal['decisions'])
    decisions = read_json(decisions_path)
    # The evaluator grants labels only against the persisted sealed prediction bytes.
    labels = bridge.evaluate_labels(session, pred_path,
        dict(sha256=seal['predictions']['sha256'], session_identity=session.identity))
    with np.load(pred_path, allow_pickle=False) as saved:
        probabilities = saved['all_probabilities']
        if (str(saved['session_identity'].item()) != session.identity
                or digest(saved['event_uids'].tolist()) != seal['query_signature']
                or probabilities.shape != (72,len(labels),2)):
            raise ValueError('Sealed prediction identities/coverage changed')
    rows = []
    for spec,p in zip(decisions['methods'],probabilities):
        k, info = spec['k'], spec['information']
        row = dict(participant=task['participant'], session=str(session.session_id), seed=task['seed'],
            generator=task['generator'], amplitude=task['amplitude'], rho=spec['rho'], model=spec['model'],
            method=spec['method'], information=info, k=k, stage=spec['stage'],
            observed_positions=12+k, revealed_labels=12+k if info=='sentinel_XY' else 12,
            elapsed_positions=20, valid_support=seal['valid_support'], valid_sentinel=spec['valid_sentinel'],
            query_signature=seal['query_signature'], initial_fit_identity=spec['initial_fit_identity'],
            selected_fit_identity=spec['selected_fit_identity'], role=task.get('role','pilot'),
            decision_factor=(spec.get('decision') or {}).get('factor'), **metrics(labels,p))
        rows.append(row)
    stream = io.StringIO(newline='')
    writer = csv.DictWriter(stream,fieldnames=list(rows[0]),lineterminator='\n')
    writer.writeheader();writer.writerows(rows)
    atomic_bytes(folder / 'metrics.csv',stream.getvalue().encode())
    label_bytes=io.BytesIO();np.savez_compressed(label_bytes,labels=np.asarray(_np(labels),dtype=np.int64))
    atomic_bytes(folder / 'evaluation-labels.npz',label_bytes.getvalue())
    receipt=dict(**base_identity,status='COMPLETE',participant=task['participant'],
        session=str(session.session_id),rows=len(rows),query_signature=seal['query_signature'],
        independent_confirmation=False,scope='RETROSPECTIVE_EXPLORATORY_REPLAY',
        fit_provenance=decisions['fit_provenance'],completed_utc=utc(),
        files={'metrics':_descriptor(folder/'metrics.csv',output),
               'prediction_seal':_descriptor(seal_path,output),
               'predictions':seal['predictions'],'decisions':seal['decisions'],
               'evaluation_labels':_descriptor(folder/'evaluation-labels.npz',output)})
    atomic_json(receipt_path,receipt)
    _notice(progress,stage='session_complete',session=session.session_id,rows=len(rows))
    return receipt


def run_task(plan, task, device='cuda:0', progress=None, stop=None):
    bridge = _bridge(plan,device)
    folder=task_folder(plan,task);folder.mkdir(parents=True,exist_ok=True)
    sessions=bridge.sessions(task['participant'])
    if not sessions:
        raise ValueError('Frozen participant has no eligible sessions')
    complete,failed=[],[]
    for index,session in enumerate(sessions):
        if _stopped(stop):
            return dict(status='PAUSED',task_key=task['key'],recipe_sha256=plan['recipe_sha256'])
        token=digest([str(session.participant_id),str(session.session_id),session.identity])[:20]
        unit=folder/'sessions'/token
        _notice(progress,stage='session_start',session=session.session_id,
                sessions_complete=len(complete),sessions_expected=len(sessions))
        try:
            receipt=_session(plan,task,session,bridge,unit,progress=progress,stop=stop)
            complete.append(_descriptor(unit/'receipt.json',Path(plan['output'])))
        except InterruptedError:
            return dict(status='PAUSED',task_key=task['key'],recipe_sha256=plan['recipe_sha256'])
        except Exception as error:
            failure=dict(session=str(session.session_id),session_identity=session.identity,
                error_type=type(error).__name__,message=str(error),updated_utc=utc())
            failed.append(failure)
            best_effort_json(unit/'last-error.json',failure)
            try:
                unit.mkdir(parents=True,exist_ok=True)
                with (unit/'error.log').open('a') as handle:
                    handle.write('\n'+utc()+'\n'+traceback.format_exc())
            except OSError:
                pass
            emit('R13_SESSION_ERROR_OTHER_SESSIONS_CONTINUE',task_key=task['key'],**failure)
    summary=dict(task_key=task['key'],recipe_sha256=plan['recipe_sha256'],
        sessions_expected=len(sessions),sessions_complete=len(complete),sessions_failed=failed,
        sessions_skipped=0,session_receipts=complete,scope='RETROSPECTIVE_EXPLORATORY_REPLAY',
        independent_confirmation=False,updated_utc=utc())
    atomic_json(folder/'session-summary.json',summary)
    if failed:
        return dict(summary,status='INCOMPLETE_WITH_ERRORS')
    return dict(summary,status='COMPLETE',files=complete)
