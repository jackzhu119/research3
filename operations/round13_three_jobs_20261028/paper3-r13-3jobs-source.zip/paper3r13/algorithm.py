"""R13 support-only fits and fixed exploratory keep/revert rules.

The spatial optimiser is the raw M12 Full-SGD100 rule. The capacity
control is M12 head_only_full, with spatial theta fixed at zero. Neither
fitting nor decision functions accept future query labels or query inputs.
No networking, scheduling, filesystem scans or source-data tests occur here.
"""
from __future__ import annotations

import copy
import hashlib
import json
import math

import numpy as np
import torch
from torch.nn import functional as F

ALGORITHM_VERSION = "paper3-r13-raw-spatial100-head65-observation-v1"
FLOOR = 1e-12


class FitPaused(RuntimeError):
    """An externally requested pause with its raw coefficients checkpointed."""

    def __init__(self, cache_key, completed_steps):
        super().__init__("fit paused after completed step %d" % completed_steps)
        self.cache_key = cache_key
        self.completed_steps = completed_steps


class NumericalFitError(ValueError):
    pass


def _notice(callback, **fields):
    if callback is not None:
        try:
            callback(**fields)
        except Exception:
            # Display/telemetry errors must never stop a scientific fit.
            pass


def _stopped(stop):
    if stop is None:
        return False
    return bool(stop.is_set() if hasattr(stop, "is_set") else stop() if callable(stop) else stop)


def _np(value):
    return value.detach().cpu().numpy() if isinstance(value, torch.Tensor) else np.asarray(value)


def _identity(value):
    if isinstance(value, torch.Tensor):
        value = value.detach().cpu().contiguous()
        shape, dtype, raw = tuple(value.shape), str(value.dtype), value.numpy().tobytes()
    else:
        value = np.ascontiguousarray(value)
        shape, dtype, raw = tuple(value.shape), str(value.dtype), value.tobytes()
    h = hashlib.sha256(str((shape, dtype)).encode()); h.update(raw)
    return h.hexdigest()


def _options(config):
    optimizer = (config or {}).get("optimizer", {})
    result = dict(steps=int(optimizer.get("primary_steps", 100)),
                  lr=float(optimizer.get("theta_learning_rate", .05)),
                  l2=float(optimizer.get("theta_l2", .01)),
                  radius=float(optimizer.get("theta_radius", .15)),
                  head_lr=float(optimizer.get("head_learning_rate", .01)),
                  head_penalty=float(optimizer.get("head_l2", .001)),
                  head_penalty_denominator=65.)
    if (result["steps"] < 1 or any(not math.isfinite(float(v)) for v in result.values())
            or min(result["lr"], result["radius"], result["head_lr"]) <= 0
            or min(result["l2"], result["head_penalty"]) < 0):
        raise ValueError("finite positive optimizer settings required")
    return result


def _device_dtype(model):
    return torch.device(getattr(model, "device", "cpu")), getattr(model, "dtype", torch.float64)


def _margin(model, theta, x, *, head_w=None, head_b=None, reference=False):
    fn = getattr(model, "reference_margin", model.margin) if reference else model.margin
    output = fn(theta, x, head_w=head_w, head_b=head_b) if head_w is not None else fn(theta, x)
    if not isinstance(output, torch.Tensor) or output.shape != (len(x),):
        raise ValueError("model margin must return one Tensor margin per trial")
    if not torch.isfinite(output).all():
        raise NumericalFitError("nonfinite prediction margins")
    return output


def _balanced_loss(margin, y):
    if not bool((y == 0).any()) or not bool((y == 1).any()):
        raise ValueError("balanced loss requires both classes")
    loss = F.softplus(margin.double()) - y.double() * margin.double()
    return .5 * (loss[y == 0].mean() + loss[y == 1].mean())


def anchor_state(model):
    return dict(theta=[0.] * int(model.dimension), method="support_ea",
                fit_status="ANCHOR", steps=0, algorithm_version=ALGORITHM_VERSION)


def fit(model, support_x, support_y, reference_x=None, *, kind="spatial", seed=0,
        budget=12, config=None, raw_cache=None, checkpoint=None, progress=None, stop=None):
    """Fit one initial or additional-label control; states are JSON serializable.

    Checkpoint identities bind actual tensors, fixed EA/source model, optimiser
    and method. The runner supplies immutable event IDs in episode_identity.
    Checkpoint callbacks are scientific durability operations and may raise;
    progress callbacks are best effort. A stop requests an orderly raw save.
    """
    if kind not in ("spatial", "full_head"):
        raise ValueError("kind must be spatial or full_head")
    options = _options(config)
    device, dtype = _device_dtype(model)
    x = torch.as_tensor(support_x, device=device, dtype=dtype)
    original_y = torch.as_tensor(support_y, device=device)
    if (original_y.is_complex() or not bool(((original_y == 0) | (original_y == 1)).all())):
        raise ValueError("support labels must be exact binary values")
    y = original_y.to(dtype=torch.long)
    if x.ndim < 2 or y.shape != (len(x),) or not torch.isfinite(x).all():
        raise ValueError("finite support trials with matching labels required")
    dimension = int(model.dimension)
    zero = torch.zeros(dimension, device=device, dtype=dtype)
    feature_dimension = int(getattr(model, "feature_dim", 0))
    if kind == "full_head" and feature_dimension <= 0:
        raise ValueError("full_head requires model.feature_dim")
    result = dict(theta=[0.] * dimension, method="full_sgd" if kind == "spatial" else "head_only_full",
                  layer="raw" if kind == "spatial" else "head_only_raw",
                  kind=kind, steps=0, fit_status="FALLBACK_SUPPORT",
                  fallback_reason="empty_or_single_class_support", source_seed=int(seed),
                  acquired_budget=int(budget), query_used_for_fitting=False,
                  algorithm_version=ALGORITHM_VERSION, optimizer=options,
                  spatial_parameters_trained=kind == "spatial", head_parameters_trained=kind == "full_head")
    if kind == "full_head":
        result.update(head_w=[0.] * feature_dimension, head_b=0., head_physical_penalty_denominator=65)
    if not bool((y == 0).any()) or not bool((y == 1).any()):
        return result
    identity = dict(version=ALGORITHM_VERSION, kind=kind, support_x=_identity(x), support_y=_identity(y),
                    model=getattr(model, "cache_identity", getattr(model, "identity", type(model).__name__)),
                    source_seed=int(seed), budget=int(budget), options=options,
                    episode=(config or {}).get("episode_identity"))
    key = kind + "-" + hashlib.sha256(json.dumps(identity, sort_keys=True, default=str).encode()).hexdigest()
    cache = {} if raw_cache is None else raw_cache
    saved = cache.get(key)
    parameter_dimension = dimension if kind == "spatial" else feature_dimension
    if saved is not None:
        if saved.get("cache_identity") != key:
            raise ValueError("raw checkpoint identity mismatch")
        coefficient = torch.as_tensor(saved["coefficient"], device=device, dtype=dtype)
        bias = torch.as_tensor(saved.get("head_b", 0.), device=device, dtype=dtype)
        completed = int(saved["completed_steps"])
        if (coefficient.shape != (parameter_dimension,) or bias.shape != ()
                or not torch.isfinite(coefficient).all() or not torch.isfinite(bias)
                or not 0 <= completed <= options["steps"]):
            raise ValueError("invalid raw checkpoint state")
    else:
        coefficient = torch.zeros(parameter_dimension, device=device, dtype=dtype)
        bias = torch.zeros((), device=device, dtype=dtype)
        completed = 0

    # Head-only M12 gradients need no repeated frozen EEGNet forward. Preserve
    # its feature dtype and the explicit casts in NativeMarginModel.margin.
    features = base_margin = None
    if kind == "full_head":
        with torch.no_grad():
            features = model.features(zero, x).detach()
            base_margin = _margin(model, zero, x).detach()
        if features.shape != (len(x), feature_dimension) or not torch.isfinite(features).all():
            raise ValueError("finite frozen head features required")

    def save(done, durable=False):
        record = dict(cache_identity=key, coefficient=coefficient.detach().cpu().tolist(),
                      head_b=float(bias.detach()), completed_steps=int(done),
                      status="RAW_FIT_COMPLETE" if done == options["steps"] else "RAW_FIT_CHECKPOINT")
        cache[key] = record
        if durable and checkpoint is not None:
            checkpoint(key, copy.deepcopy(record))
        return record

    for step in range(completed, options["steps"]):
        if _stopped(stop):
            save(step, True)
            raise FitPaused(key, step)
        variable = coefficient.detach().requires_grad_(True)
        if kind == "spatial":
            loss = _balanced_loss(_margin(model, variable, x), y) + options["l2"] * variable.square().sum()
            gradient, = torch.autograd.grad(loss, variable)
            gradients = (gradient,)
            if not torch.isfinite(loss) or not torch.isfinite(gradient).all():
                raise NumericalFitError("nonfinite spatial loss/gradient; raw state preserved")
            coefficient = (variable - options["lr"] * gradient).detach()
            coefficient = coefficient / (torch.linalg.vector_norm(coefficient) / options["radius"]).clamp_min(1.)
        else:
            variable_bias = bias.detach().requires_grad_(True)
            margin = base_margin + (features @ variable.to(features.dtype)).to(dtype) + variable_bias
            loss = (_balanced_loss(margin, y) + options["head_penalty"] *
                    (variable.square().sum() + variable_bias.square()) / options["head_penalty_denominator"])
            gradients = torch.autograd.grad(loss, (variable, variable_bias))
            if not torch.isfinite(loss) or not all(torch.isfinite(g).all() for g in gradients):
                raise NumericalFitError("nonfinite head loss/gradient; raw state preserved")
            coefficient = (variable - options["head_lr"] * gradients[0]).detach()
            bias = (variable_bias - options["head_lr"] * gradients[1]).detach()
        done = step + 1
        if done % 10 == 0 or done == options["steps"]:
            save(done, done == 10 or done % 50 == 0 or done == options["steps"])
            _notice(progress, stage="support_sgd" if kind == "spatial" else "head_only_fit",
                    step=done, total_steps=options["steps"], support_objective=float(loss.detach()),
                    raw_fit_reused=completed > 0)
    save(options["steps"], True)
    result.update(steps=options["steps"], fit_status="FITTED", fallback_reason=None, cache_identity=key)
    if kind == "spatial":
        result["theta"] = coefficient.detach().cpu().tolist()
    else:
        result.update(head_w=coefficient.detach().cpu().tolist(), head_b=float(bias))
    with torch.no_grad():
        theta = torch.as_tensor(result["theta"], device=device, dtype=dtype)
        h = torch.as_tensor(result["head_w"], device=device, dtype=dtype) if "head_w" in result else None
        b = torch.as_tensor(result.get("head_b", 0.), device=device, dtype=dtype)
        result["support_loss"] = float(_balanced_loss(_margin(model, theta, x, head_w=h, head_b=b), y))
        if reference_x is not None:
            reference = torch.as_tensor(reference_x, device=device, dtype=dtype)
            if reference.ndim != x.ndim or tuple(reference.shape[1:]) != tuple(x.shape[1:]) or not len(reference):
                raise ValueError("fixed reference signal shape must match support")
            anchor = _margin(model, zero, reference, reference=True).double()
            updated = _margin(model, theta, reference, head_w=h, head_b=b, reference=True).double()
            result["reference_rms"] = float(torch.sqrt((updated - anchor).square().mean()))
    json.dumps(result, allow_nan=False)
    return result


def predict(model, state, x, batch_size=64):
    device, dtype = _device_dtype(model)
    values = torch.as_tensor(x, device=device, dtype=dtype)
    theta = torch.as_tensor(state["theta"], device=device, dtype=dtype)
    if theta.shape != (int(model.dimension),) or not torch.isfinite(theta).all():
        raise ValueError("finite spatial prediction state required")
    if batch_size < 1 or values.ndim < 2 or not torch.isfinite(values).all():
        raise ValueError("positive batch size and finite trials required")
    head = torch.as_tensor(state["head_w"], device=device, dtype=dtype) if "head_w" in state else None
    bias = torch.as_tensor(state.get("head_b", 0.), device=device, dtype=dtype)
    output = []
    with torch.no_grad():
        for start in range(0, len(values), batch_size):
            margin = _margin(model, theta, values[start:start + batch_size], head_w=head, head_b=bias)
            p = torch.sigmoid(margin.double()).clamp(FLOOR, 1 - FLOOR)
            output.append(torch.stack((1 - p, p), dim=1).cpu().numpy())
    return np.concatenate(output) if output else np.empty((0, 2), dtype=np.float64)


def scale_state(state, factor):
    """Scale a copy of an update; never mutate the fitted object across worlds."""
    factor = float(factor)
    if not math.isfinite(factor) or not 0 <= factor <= 1:
        raise ValueError("shrink factor must be in[0,1]")
    result = copy.deepcopy(state)
    result["theta"] = [factor * float(x) for x in state["theta"]]
    if "head_w" in state:
        result["head_w"] = [factor * float(x) for x in state["head_w"]]
        result["head_b"] = factor * float(state.get("head_b", 0.))
    result["applied_shrink_factor"] = factor
    return result


def _probabilities(values):
    p = np.asarray(_np(values), dtype=np.float64)
    if (p.ndim != 2 or p.shape[1] != 2 or not np.isfinite(p).all() or np.any(p < 0)
            or np.any(p > 1) or not np.allclose(p.sum(1), 1., rtol=0, atol=1e-7)):
        raise ValueError("finite normalized binary probabilities required")
    p = np.clip(p, FLOOR, 1 - FLOOR)
    return p / p.sum(1, keepdims=True)


def _labels(values, n):
    y = _np(values)
    if y.shape != (n,) or not np.isin(y, [0, 1]).all():
        raise ValueError("exact binary labels matching predictions required")
    return y.astype(np.int64)


def _excess_loss(anchor, adapt, y):
    return -np.log(adapt[np.arange(len(y)), y]) + np.log(anchor[np.arange(len(y)), y])


def _balanced(values, y):
    return float(.5 * sum(values[y == c].mean() for c in (0, 1)))


def _covariance(x):
    value = np.asarray(_np(x), dtype=np.float64)
    if value.ndim < 2 or not len(value) or not np.isfinite(value).all():
        raise ValueError("finite nonempty observed X required")
    if value.ndim == 2:
        value = value[:, :, None]
    else:
        value = value.reshape(value.shape[0], value.shape[1], -1)
    covariance = value @ np.swapaxes(value, -1, -2)
    traces = np.trace(covariance, axis1=1, axis2=2)
    if np.any(traces <= 0):
        raise ValueError("positive observed trial covariance trace required")
    return (covariance / traces[:, None, None]).mean(0)


def decide(support_predictions, sentinel_predictions, support_y, sentinel_y=None, *,
           support_x=None, sentinel_x=None, config=None):
    """Fixed exploratory rules, using only initial and declared later samples.

    X-only rules never use sentinel_y. XY rules compare balanced later loss.
    The uncertainty score is a small-sample heuristic, not a distribution-free
    confidence bound or a guarantee about an arbitrary future distribution.
    All thresholds are immutable execution configuration, not tuned on Q.
    """
    settings = (config or {}).get("decision", config or {})
    footprint_limit = float(settings.get("footprint_shift_limit", .5))
    covariance_limit = float(settings.get("covariance_shift_limit", .5))
    consistency_limit = float(settings.get("confidence_shift_limit", .1))
    uncertainty_multiplier = float(settings.get("uncertainty_multiplier", 1.645))
    if (not all(math.isfinite(v) for v in (footprint_limit, covariance_limit, consistency_limit, uncertainty_multiplier))
            or min(footprint_limit, covariance_limit, consistency_limit, uncertainty_multiplier) < 0):
        raise ValueError("decision thresholds must be finite nonnegative")
    a = _probabilities(support_predictions["EA"])
    u = _probabilities(support_predictions["adapt"])
    if a.shape != u.shape:
        raise ValueError("initial paired predictions must have identical trial coverage")
    y = _labels(support_y, len(a))
    sa = _probabilities(sentinel_predictions["EA"])
    su = _probabilities(sentinel_predictions["adapt"])
    if sa.shape != su.shape:
        raise ValueError("sentinel paired predictions must have identical trial coverage")
    available = len(sa)

    def record(factor=0., reason="insufficient_observation", **fields):
        return dict(factor=float(factor), status="KEEP" if factor else "REVERT", reason=reason,
                    sentinel_count=available, uncertainty_is_future_guarantee=False, **fields)

    output = {name: record() for name in ("candidate_X", "generic_shift_X", "consistency_X", "candidate_XY", "holdout_XY")}
    support_has_both = set(y.tolist()) == {0, 1}
    support_improves = support_has_both and _balanced(_excess_loss(a, u, y), y) < 0
    if available and len(a):
        initial_footprint = np.log(u[:, 1] / u[:, 0]) - np.log(a[:, 1] / a[:, 0])
        later_footprint = np.log(su[:, 1] / su[:, 0]) - np.log(sa[:, 1] / sa[:, 0])
        scale = math.sqrt(float(np.mean(initial_footprint ** 2))) + .1
        footprint_change = max(abs(float(later_footprint.mean() - initial_footprint.mean())),
                               abs(math.sqrt(float(np.mean(later_footprint ** 2)))
                                   - math.sqrt(float(np.mean(initial_footprint ** 2))))) / scale
        keep = support_improves and footprint_change <= footprint_limit
        output["candidate_X"] = record(keep, "fixed_update_footprint_rule", score=footprint_change,
                                        threshold=footprint_limit, support_fit_improves=bool(support_improves), revealed_sentinel_labels=0)
        confidence_change = abs(float(sa.max(1).mean() - a.max(1).mean()))
        output["consistency_X"] = record(support_improves and confidence_change <= consistency_limit,
                                          "fixed_anchor_confidence_rule", score=confidence_change,
                                          threshold=consistency_limit, revealed_sentinel_labels=0)
        if support_x is not None and sentinel_x is not None:
            covariance0, covariance1 = _covariance(support_x), _covariance(sentinel_x)
            if covariance0.shape != covariance1.shape:
                raise ValueError("initial and sentinel channel coverage must match")
            change = float(np.linalg.norm(covariance1 - covariance0) / (np.linalg.norm(covariance0) + 1e-12))
            output["generic_shift_X"] = record(support_improves and change <= covariance_limit,
                                                "fixed_observed_covariance_rule", score=change,
                                                threshold=covariance_limit, revealed_sentinel_labels=0)
        else:
            output["generic_shift_X"] = record(reason="observed_X_not_supplied", revealed_sentinel_labels=0)
    if sentinel_y is None:
        for name in ("candidate_XY", "holdout_XY"):
            output[name] = record(reason="sentinel_labels_not_revealed", revealed_sentinel_labels=0)
        return output
    sy = _labels(sentinel_y, available)
    if not available or set(sy.tolist()) != {0, 1}:
        for name in ("candidate_XY", "holdout_XY"):
            output[name] = record(reason="empty_or_single_class_sentinel", revealed_sentinel_labels=available)
        return output
    delta = _excess_loss(sa, su, sy)
    mean = _balanced(delta, sy)
    output["holdout_XY"] = record(mean < 0, "ordinary_balanced_holdout_mean", mean_excess_loss=mean,
                                   revealed_sentinel_labels=available)
    counts = [int((sy == c).sum()) for c in (0, 1)]
    if min(counts) < 2:
        output["candidate_XY"] = record(reason="insufficient_class_replicates_for_uncertainty",
                                          mean_excess_loss=mean, revealed_sentinel_labels=available)
    else:
        se = .5 * math.sqrt(sum(float(np.var(delta[sy == c], ddof=1)) / counts[c] for c in (0, 1)))
        upper = mean + uncertainty_multiplier * se
        output["candidate_XY"] = record(upper < 0, "exploratory_balanced_loss_uncertainty_rule",
                                          mean_excess_loss=mean, standard_error=se, heuristic_upper_score=upper,
                                          uncertainty_multiplier=uncertainty_multiplier,
                                          revealed_sentinel_labels=available)
    json.dumps(output, allow_nan=False)
    return output
