"""Read-only bridge to the already installed school M12 native inputs.

Preparation reads small JSON metadata only.  Each worker keeps its provider,
source models and catalogs alive; it does not rediscover or hash the source
tree between sessions.  Initial support, later observations and final-query
labels remain separate capabilities.
"""
from __future__ import annotations

from dataclasses import dataclass
import hashlib
import importlib
import json
import math
import os
from pathlib import Path
import sys


M12_SCHEMA = "paper3m12-native-inputs-v1"
M12_REFERENCE_COMMIT = "653dc25a2f09ed11361fe71d795f4fd31a47f1ba"
M12_RAW_ALGORITHM_SHA256 = "cc850be6b96fd329b2a1189093bf0f97ed8a78e0b3b8574bfdf2f35092baa856"
DEFAULT_ROOT = Path("/public/home/zhuziyuan/projects/paper3")
DEFAULT_PLAN = DEFAULT_ROOT / "runs/r12_controlled_mechanism/plan.json"
_JSON_LIMIT = 32 * 1024 * 1024


def _read(path):
    path = Path(path)
    with path.open("rb") as handle:
        size = os.fstat(handle.fileno()).st_size
        if size < 0 or size > _JSON_LIMIT:
            raise ValueError("Native input metadata exceeds32MiB: " + str(path))
        value = json.loads(handle.read(size + 1))
    if not isinstance(value, dict):
        raise ValueError("Native input JSON object required: " + str(path))
    return value


def _digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"),
                                    ensure_ascii=False, allow_nan=False).encode()).hexdigest()


def _sha(path):
    value = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            value.update(chunk)
    return value.hexdigest()


def _resolve(root, value):
    value = value.get("path") if isinstance(value, dict) else value
    if not isinstance(value, str) or not value:
        raise ValueError("Concrete native metadata path required")
    path = Path(value).expanduser()
    return path.resolve() if path.is_absolute() else (Path(root) / path).resolve()


def _package(plan, explicit=None):
    candidates = []
    if explicit is not None:
        candidates.append(Path(explicit).expanduser())
    for key in ("package", "m12_package"):
        if isinstance(plan.get(key), str):
            candidates.append(Path(plan[key]).expanduser())
    if isinstance(plan.get("worker_entry"), str):
        candidates.append(Path(plan["worker_entry"]).expanduser().parent.parent)
    # Narrow known installation root; no recursive project or data discovery.
    installed = Path.home() / "paper3-mechanism12"
    if installed.is_dir():
        candidates.extend(sorted(installed.iterdir()))
    for path in candidates:
        path = path.resolve()
        if (path / "paper3m12/native_data.py").is_file() and (path / "paper3m12/vendor/paper3r11/data.py").is_file():
            return path
    raise FileNotFoundError("Installed M12 source package not found; provide --m12-package. Expected paper3m12/native_data.py and its native vendor directory.")


def _frozen(plan):
    root = Path(plan["root"]).expanduser().resolve()
    value = plan.get("native_inputs")
    if not isinstance(value, dict):
        raise ValueError("Existing M12 plan lacks its frozen native input descriptor")
    # Public analytical plans may omit large registry/root fields.  The school
    # installation retains the immutable manifest referenced by that summary.
    if "registry" not in value or "root" not in value:
        descriptor = value.get("manifest_descriptor")
        path = _resolve(root, descriptor)
        if isinstance(descriptor, dict):
            if descriptor.get("bytes") is not None and path.stat().st_size != descriptor["bytes"]:
                raise ValueError("Frozen M12 manifest byte identity changed")
            if descriptor.get("sha256") and _sha(path) != descriptor["sha256"]:
                raise ValueError("Frozen M12 manifest SHA256 changed")
        value = _read(path)
    value = json.loads(json.dumps(value))
    if value.get("schema_version") != M12_SCHEMA or Path(value.get("root", "")).resolve() != root:
        raise ValueError("Frozen M12 input schema/root differs")
    raw = {k: v for k, v in value.items() if k not in ("input_identity", "manifest_descriptor")}
    if value.get("input_identity") != _digest(raw):
        raise ValueError("Frozen M12 input metadata identity differs")
    return root, value


def prepare_inputs(m12_plan_path=DEFAULT_PLAN, m12_package=None, role="pilot"):
    """Resolve original metadata once on login node; does not import Torch."""
    path = Path(m12_plan_path).expanduser().resolve()
    old = _read(path)
    root, inputs = _frozen(old)
    package = _package(old, m12_package)
    role = {"development": "meta_validation"}.get(role, role)
    if role not in ("pilot", "meta_validation"):
        raise ValueError("This release runs exploratory pilot/meta_validation only; it does not invent an independent cohort")
    people = inputs["people"].get(role)
    if not isinstance(people, list) or not people or len(set(people)) != len(people):
        raise ValueError("Frozen exploratory participant list is unavailable or duplicated")
    seeds = sorted(int(x) for x in inputs["source_by_seed"])
    if seeds != [20261018, 20261019, 20261020]:
        raise ValueError("Expected the three already trained M12 source seeds")
    return dict(m12_plan_path=str(path), m12_package=str(package), root=str(root),
                input_identity=inputs["input_identity"], participants=list(people),
                source_seeds=seeds, role=role,
                native_manifest_identity=inputs["input_identity"],
                native_data_sha256=_sha(package / "paper3m12/native_data.py"),
                native_bridge_reference_commit=M12_REFERENCE_COMMIT,
                scientific_scope="retrospective_exploratory_replay",
                independent_confirmation_available=False)


@dataclass(frozen=True)
class SentinelInputs:
    """Only later EEG inputs and acquisition accounting, never labels."""
    x: object
    event_uids: tuple
    acquired_event_uids: tuple
    valid_mask: tuple
    acquired_positions: tuple
    identity: str


class Bridge:
    def __init__(self, plan, device="cpu"):
        descriptor = plan.get("native_inputs", plan)
        original_path = plan.get("m12_plan_path", descriptor.get("m12_plan_path"))
        if original_path is None:
            raise ValueError("R13 plan requires its original M12 plan path")
        original = _read(original_path)
        root, inputs = _frozen(original)
        expected = plan.get("input_identity", descriptor.get("input_identity"))
        if expected and inputs["input_identity"] != expected:
            raise ValueError("R13 frozen input identity differs from its M12 preparation")
        explicit = plan.get("m12_package", descriptor.get("m12_package"))
        package = _package(original, explicit)
        expected_code = descriptor.get("native_data_sha256")
        if expected_code and _sha(package / "paper3m12/native_data.py") != expected_code:
            raise ValueError("M12 native bridge code changed after R13 preparation")
        existing = sys.modules.get("paper3m12")
        if existing is not None and not Path(existing.__file__).resolve().is_relative_to(package):
            raise ValueError("A different M12 package was already imported in this worker")
        if str(package) not in sys.path:
            sys.path.insert(0, str(package))
        self.module = importlib.import_module("paper3m12.native_data")
        self._original_plan = original
        self._original_output = _resolve(root, original["output"])
        code_manifest = original.get("code_manifest", {})
        recorded_algorithm = code_manifest.get("paper3m12/algorithm.py")
        algorithm_path = package / "paper3m12/algorithm.py"
        self._raw_reuse_code_bound = (
            recorded_algorithm == M12_RAW_ALGORITHM_SHA256 and algorithm_path.is_file()
            and _sha(algorithm_path) == M12_RAW_ALGORITHM_SHA256)
        self.last_reuse_reason = "not_attempted"
        # DataProvider verifies source/catalog/checkpoint on first use and then
        # performs only cheap in-memory frozen-tensor guards on cache hits.
        provider_plan = dict(root=str(root), native_inputs=inputs)
        self.provider = self.module.DataProvider(provider_plan, device=device)
        # Scope this source-cache adapter to this new worker instance.  Native
        # loading validates the source/checkpoint on its first use.  The fitted
        # parameters belong only to the four-dimensional adapter or head delta;
        # the source stays frozen.  There is no source-tree or parameter scan
        # for every later fit, branch or prediction.
        original_source = self.provider._source
        source_cache = {}
        self.source_tensor_versions = {}

        def once_source(seed):
            seed = int(seed)
            if seed not in source_cache:
                loaded = original_source(seed)
                source, geometry, _identity = loaded
                source.eval()
                for parameter in source.parameters():
                    parameter.requires_grad_(False)
                self.source_tensor_versions[seed] = tuple(
                    (name, id(value), value._version)
                    for name, value in tuple(source.named_parameters()) + tuple(source.named_buffers()))
                source_cache[seed] = loaded
            return source_cache[seed]

        self.provider._source = once_source
        self.device = self.provider.device
        self.runtime_profile = dict(self.provider.runtime_profile)
        requested_threads = os.environ.get("R13_CPU_THREADS")
        if requested_threads:
            import torch
            torch.set_num_threads(max(1, int(requested_threads)))
            self.runtime_profile["torch_cpu_threads"] = torch.get_num_threads()
        self.role = plan.get("role", descriptor.get("role", "pilot"))
        self.root = root
        self.input_identity = inputs["input_identity"]
        self._active_seed = None
        self._matrices = {}
        self._sessions = {}

    def participants(self):
        return self.provider.participants(self.role)

    def sessions(self, participant):
        if participant not in self._sessions:
            self._sessions[participant] = tuple(self.provider.sessions(self.role, participant))
        return list(self._sessions[participant])

    def initial(self, session):
        return self.provider.support(session, 12)

    def sentinel_inputs(self, session, k):
        k = int(k)
        if k not in (0, 4, 8):
            raise ValueError("Only0/4/8 original subsequent positions are registered")
        access = self.provider._access(session)
        original = tuple(access._session.audit["acquired_prefix_uids"])
        acquired = original[12:12 + k]
        rows = access._session.rows
        mask = tuple(bool(rows[u]["valid"]) for u in acquired)
        valid = tuple(u for u, yes in zip(acquired, mask) if yes)
        return SentinelInputs(access._x(valid), valid, acquired, mask,
                              tuple(range(13, 13 + k)),
                              _digest(dict(session=session.identity, acquired=acquired, valid=valid)))

    def reveal_sentinel_labels(self, session, k):
        # A separate capability; the fitting/decision code explicitly chooses
        # whether it has paid to reveal these labels.  No final-query UID is
        # accepted here and invalid positions are never replenished.
        view = self.sentinel_inputs(session, k)
        access = self.provider._access(session)
        import torch
        return torch.tensor([access._session.rows[u]["label"] for u in view.event_uids],
                            dtype=torch.long, device=self.device)

    def query_inputs(self, session):
        return self.provider.query_inputs(session)

    def evaluate_labels(self, session, prediction_path, expected_identity):
        return self.provider.evaluate_labels(session, prediction_path, expected_identity)

    def model(self, seed, support):
        self._active_seed = int(seed)
        return self.provider.episode_model(seed, support)

    def ea_model(self, seed, x, event_uids, acquired_event_uids):
        """Updated-EA baseline using acquired X alone, with no label argument."""
        self._active_seed = int(seed)
        source, geometry, identity = self.provider._source(seed)
        transform, fallback = self.module._fit_ea(geometry, x)
        descriptor = self.provider.inputs["dictionary_by_seed"][str(int(seed))]
        fingerprint = hashlib.sha256(x.detach().cpu().contiguous().numpy().tobytes()).hexdigest()
        result = self.module.NativeMarginModel(source, geometry, self.provider._dictionary(seed),
            alignment=transform,
            identity=dict(seed=int(seed), source=identity,
                native_input_identity=self.input_identity,
                dictionary_sha256=descriptor["checkpoint"]["sha256"],
                EA="support_only_unit_trace_shrinkage_0.05",
                EA_support_uids=list(event_uids), acquired_event_uids=list(acquired_event_uids),
                support_signal_sha256=fingerprint, support_labels_read=False,
                EA_fallback_reason=fallback))
        result.ea_fallback_reason = fallback
        return result

    def reference(self, seed):
        self._active_seed = int(seed)
        return self.provider.reference(seed)

    def reuse_initial(self, session, seed, generator, amplitude, model_identity, config):
        """Reuse only an identity-bound raw M12 spatial SGD100 state.

        Missing/incomplete or semantically different old results simply cause
        a fresh fit.  This never ranks candidate states by evaluation metrics,
        opens query-label arrays, or waits for the running M12 experiment.
        Only its small states.json file is hashed; the older output tree and
        prediction/evaluation artifacts are not scanned.
        """
        def miss(reason):
            self.last_reuse_reason = reason
            return None

        if not self._raw_reuse_code_bound:
            return miss("old_raw_algorithm_code_not_bound")
        if session.role != "pilot" or not isinstance(model_identity, dict):
            return miss("no_matching_pilot_model_identity")
        old = self._original_plan
        optimizer = old.get("config", {}).get("optimizer", {})
        new_optimizer = (config or {}).get("optimizer", {})
        locked = dict(primary_steps=100, theta_learning_rate=.05, theta_l2=.01, theta_radius=.15)
        if any(float(optimizer.get(k, v)) != v or float(new_optimizer.get(k, v)) != v
               for k, v in locked.items()):
            return miss("optimizer_configuration_differs")
        if optimizer.get("head_frozen_primary", True) is not True:
            return miss("old_primary_head_not_frozen")
        task_key = "shift-pilot-%s-s%d" % (session.participant_id, int(seed))
        task = next((item for item in old.get("tasks", ()) if item.get("key") == task_key), None)
        if (not isinstance(task, dict) or task.get("kind") != "shift_block"
                or task.get("role") != "pilot" or str(task.get("participant")) != session.participant_id
                or int(task.get("seed", -1)) != int(seed)):
            return miss("old_task_identity_unavailable")
        token = _digest([str(session.participant_id), str(session.session_id), session.identity])[:20]
        base = self._original_output / "tasks" / task_key / "units" / ("session-" + token) / "B12"
        support_uids = tuple(self.initial(session).event_uids)
        acquired_uids = tuple(session.audit["acquired_prefix_uids"][:12])
        for scope in ("persistent", "support_only"):
            name = "shift-%s-g%d-a%s" % (scope, int(generator), str(float(amplitude)).replace(".", "p"))
            unit = base / name
            receipt_path, state_path = unit / "receipt.json", unit / "states.json"
            if not receipt_path.is_file() or not state_path.is_file():
                continue
            try:
                receipt = _read(receipt_path)
                identity = receipt.get("unit_identity", {})
                old_config = json.loads(json.dumps(old.get("config", {})))
                old_config["episode_identity"] = dict(role="pilot", participant=task["participant"],
                    session=str(session.session_id), budget=12, source_seed=int(seed), intervention=name)
                if (receipt.get("status") != "COMPLETE"
                        or identity.get("recipe_sha256") != old.get("recipe_sha256")
                        or identity.get("task_identity") != _digest(task)
                        or identity.get("session_identity") != session.identity
                        or identity.get("budget") != 12
                        or tuple(identity.get("support_event_uids", ())) != support_uids
                        or tuple(identity.get("acquired_event_uids", ())) != acquired_uids
                        or identity.get("source_identity") != model_identity
                        or identity.get("config_sha256") != _digest(old_config)
                        or identity.get("intervention") != name):
                    self.last_reuse_reason = "old_unit_semantic_identity_differs"
                    continue
                relative_state = state_path.relative_to(self._original_output).as_posix()
                descriptor = next((item for item in receipt.get("files", ())
                                   if item.get("path") == relative_state), None)
                if (not isinstance(descriptor, dict) or state_path.is_symlink()
                        or state_path.stat().st_size != descriptor.get("bytes")
                        or _sha(state_path) != descriptor.get("sha256")):
                    self.last_reuse_reason = "old_unit_state_seal_differs"
                    continue
                saved = _read(state_path)
                state = saved.get("fit", {}).get("states", {}).get("full_sgd")
                if (saved.get("unit_identity") != identity or not isinstance(state, dict)
                        or state.get("method") != "full_sgd"
                        or state.get("layer") != "shift_raw_control"
                        or state.get("fit_status") != "FITTED" or state.get("steps") != 100
                        or float(state.get("scale", 1.)) != 1.
                        or "head_w" in state or "head_b" in state):
                    self.last_reuse_reason = "old_state_is_not_raw_spatial100"
                    continue
                theta = state.get("theta")
                if (not isinstance(theta, list) or len(theta) != 4
                        or any(not math.isfinite(float(v)) for v in theta)
                        or math.sqrt(sum(float(v)**2 for v in theta)) > .15 + 1e-8):
                    self.last_reuse_reason = "old_state_coefficient_shape_or_radius_differs"
                    continue
                proof = dict(source="identity_bound_M12_raw_shift_control", task_key=task_key,
                    receipt_path=str(receipt_path), states_path=str(state_path),
                    states_sha256=descriptor["sha256"], recipe_sha256=old["recipe_sha256"],
                    algorithm_sha256=M12_RAW_ALGORITHM_SHA256,
                    unit_identity_sha256=_digest(identity), fixed_tau_in_original_unit=identity.get("fixed_tau"),
                    matching_applied=False, query_labels_read=False, metrics_used_for_selection=False,
                    reuse_scope="fitted_raw_spatial_state_only_not_query_predictions")
                self.last_reuse_reason = "identity_bound_raw_state_reused"
                return dict(state=json.loads(json.dumps(state)), proof=proof)
            except (OSError, ValueError, TypeError, KeyError, OverflowError):
                self.last_reuse_reason = "old_unit_temporarily_unreadable_or_unbound"
                continue
        if self.last_reuse_reason == "not_attempted":
            self.last_reuse_reason = "no_completed_matching_B12_unit"
        return None

    def matrix(self, seed, generator, amplitude, rho):
        import torch
        seed, generator = int(seed), int(generator)
        amplitude, rho = float(amplitude), float(rho)
        if generator not in (0, 1) or amplitude not in (.05, .15) or rho not in (0., .25, .5, .75, 1.):
            raise ValueError("Unregistered R13 nuisance generator/amplitude/persistence")
        key = (seed, generator, amplitude, rho)
        if key not in self._matrices:
            _, geometry, _ = self.provider._source(seed)
            basis = self.provider._dictionary(seed)
            with torch.no_grad():
                theta = torch.zeros(4, device=basis.device, dtype=basis.dtype)
                theta[generator] = amplitude
                full, _, _ = geometry.matrix(theta, basis, family="exp")
                identity = torch.eye(full.shape[0], device=full.device, dtype=full.dtype)
                value = identity + rho * (full - identity)
                # Native geometry.matrix is a CAR map and has a null common
                # mode in the full sensor space.  Invertibility is meaningful
                # only on the registered (C-1)-dimensional CAR subspace; using
                # the full CxC minimum singular value would reject every rho1
                # endpoint despite valid native input geometry.
                reduced = geometry.q @ value @ geometry.q.T
                singular = torch.linalg.svdvals(reduced)
                if not bool(torch.isfinite(value).all()) or float(singular.min()) <= 1e-10:
                    raise ValueError("Registered nuisance persistence path is not finite/invertible on its CAR subspace")
                self._matrices[key] = value.detach()
        return self._matrices[key]

    def transform(self, x, generator, amplitude, rho, seed=None):
        """Interpolate the matrix, then use native joint-trial RMS once.

        rho0 is the exact M12 support_only raw-input endpoint.  For positive
        rho, mixing occurs before normalization, never between normalized
        waveforms.  The source model applies its own fixed post-EA RMS path.
        """
        import torch
        selected = self._active_seed if seed is None else int(seed)
        if selected is None:
            raise ValueError("transform requires seed before the first model/reference call")
        matrix = self.matrix(selected, generator, amplitude, rho)
        if float(rho) == 0.:
            return x
        with torch.no_grad():
            value = matrix @ x.to(device=matrix.device, dtype=matrix.dtype)
            normalizer = self.provider._module.native("p3work.spatial_geometry").joint_trial_rms
            return normalizer(value)

