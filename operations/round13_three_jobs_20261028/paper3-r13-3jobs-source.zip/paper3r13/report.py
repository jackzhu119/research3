"""Small, CPU-only reports from sealed R13 session metrics.

Reports are observers.  They do not open EEG arrays, import Torch, choose a
model, reset fitting state, or control a worker's progress.  Incomplete pairs
remain missing; a scheduler's COMPLETED state is not scientific completion.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import io
import itertools
import json
import math
from pathlib import Path
import random
import statistics
from typing import Any

from .common import atomic_bytes, atomic_json, digest, utc

METRICS = ("BA", "balanced_NLL", "Brier")
PRIMARY_METHOD = "retain_initial"
ANCHOR_METHOD = "EA_B12"
EXPECTED_PERTURBATIONS = {(0, .05), (0, .15), (1, .05), (1, .15)}
SPATIAL_MODELS = {"spatial", "spatial_head_frozen", "spatial_sgd100"}
_MAX_METADATA = 16 * 1024 * 1024
_MAX_METRICS = 32 * 1024 * 1024


def _read(path: Path, maximum: int = _MAX_METADATA) -> dict:
    with path.open("rb") as stream:
        value = stream.read(maximum + 1)
    if len(value) > maximum:
        raise ValueError("Report metadata exceeds bound: " + str(path))
    result = json.loads(value)
    if not isinstance(result, dict):
        raise ValueError("Report metadata must be an object: " + str(path))
    return result


def _number(value: Any) -> float | None:
    if value in (None, "", "null", "None"):
        return None
    result = float(value)
    return result if math.isfinite(result) else None


def _mean(values):
    values = [x for x in values if x is not None]
    return statistics.fmean(values) if values else None


def _quantile(values: list[float], fraction: float) -> float:
    values = sorted(values)
    at = (len(values) - 1) * fraction
    low = int(at)
    high = min(low + 1, len(values) - 1)
    return values[low] + (at - low) * (values[high] - values[low])


def _paired_statistics(values, *, alternative="two-sided", draws=2000):
    """Participant resampling and exact sign flips; no pseudo-independent seeds."""
    values = [float(x) for x in values]
    n = len(values)
    if not n:
        return {"n_participants": 0, "mean": None, "ci95": None,
                "sign_flip_p": None, "alternative": alternative}
    observed = statistics.fmean(values)
    rng = random.Random(20261028)
    boot = [statistics.fmean(rng.choices(values, k=n)) for _ in range(draws)]
    if n <= 18:
        samples = (statistics.fmean(sign * x for sign, x in zip(signs, values))
                   for signs in itertools.product((-1, 1), repeat=n))
        total = 2 ** n
        exact = True
    else:
        rng = random.Random(20261028)
        samples = (statistics.fmean(x if rng.getrandbits(1) else -x for x in values)
                   for _ in range(20000))
        total = 20000
        exact = False
    if alternative == "greater":
        extreme = sum(x >= observed - 1e-15 for x in samples)
    elif alternative == "less":
        extreme = sum(x <= observed + 1e-15 for x in samples)
    else:
        extreme = sum(abs(x) >= abs(observed) - 1e-15 for x in samples)
    p = extreme / total if exact else (extreme + 1) / (total + 1)
    return {"n_participants": n, "mean": observed,
            "ci95": [_quantile(boot, .025), _quantile(boot, .975)],
            "ci_method": "participant_percentile_bootstrap_2000_seed20261028",
            "sign_flip_p": p, "sign_flip_exact": exact,
            "test_assumption": "paired participant differences are sign-exchangeable under the null",
            "alternative": alternative}


def _csv_bytes(rows):
    buffer = io.StringIO(newline="")
    fields = ["participant", "generator", "amplitude", "rho", "model", "method",
              "information", "k", "source_seeds", "session_seed_rows", *METRICS]
    writer = csv.DictWriter(buffer, fieldnames=fields, lineterminator="\n")
    writer.writeheader()
    writer.writerows(rows)
    return buffer.getvalue().encode("utf-8")


def _state_kind(receipt):
    return str(receipt.get("status", "UNKNOWN")).upper()


def _verify_metrics_descriptor(receipt, path: Path, content: bytes):
    descriptor = receipt.get("metrics_csv")
    if descriptor is None:
        files = receipt.get("files", {})
        descriptor = (files.get("metrics") if isinstance(files, dict) else
                      next((x for x in files if isinstance(x, dict) and
                            Path(x.get("path", "")).name == path.name), None))
    if isinstance(descriptor, dict):
        if descriptor.get("bytes") is not None and int(descriptor["bytes"]) != len(content):
            raise ValueError("Sealed metrics byte count differs")
        if descriptor.get("sha256") is not None and descriptor["sha256"] != hashlib.sha256(content).hexdigest():
            raise ValueError("Sealed metrics checksum differs")


def _required_conditions():
    required = {(rho, model, method, "prefix_only", 0)
                for rho in (0., .25, .5, .75, 1.)
                for model in ("spatial", "full_head")
                for method in (PRIMARY_METHOD, ANCHOR_METHOD)}
    for rho in (0., 1.):
        for k in (4, 8):
            for info, methods in (
                ("sentinel_X_only", ("candidate_X", "generic_shift_X", "consistency_X",
                                     "updated_EA", PRIMARY_METHOD, ANCHOR_METHOD)),
                ("sentinel_XY", ("candidate_XY", "holdout_XY", "shrink_XY", "refit_all_labels",
                                 "updated_EA", PRIMARY_METHOD, ANCHOR_METHOD))):
                required.update((rho, "spatial", method, info, k) for method in methods)
    return required


def generate_report(plan_or_path) -> dict:
    plan = dict(plan_or_path) if isinstance(plan_or_path, dict) else _read(Path(plan_or_path))
    output = Path(plan["output"]).expanduser().resolve()
    issues = []
    task_status = {"COMPLETE": 0, "ERROR": 0, "SKIPPED": 0, "UNOBSERVED_OR_PARTIAL": 0}
    session_status = {"COMPLETE": 0, "ERROR": 0, "SKIPPED": 0, "REJECTED": 0}
    tasks = plan.get("tasks", [])
    expected_seeds = tuple(int(x) for x in plan.get("source_seeds", plan.get("config", {}).get(
        "source_seeds", [20261018, 20261019, 20261020])))
    # Complete session averages are collected within each participant/seed/
    # condition before seeds are averaged.  Each session therefore has equal
    # weight regardless of its number of future EEG trials.
    grouped = {}
    pairs = {}
    seen = set()
    metric_rows = 0
    for task in tasks:
        folder = output / "tasks" / str(task["key"])
        task_receipt = folder / "result.json"
        task_kind = "UNOBSERVED_OR_PARTIAL"
        if task_receipt.is_file():
            try:
                record = _read(task_receipt)
                if (record.get("recipe_sha256") != plan.get("recipe_sha256") or
                        record.get("task_key") != task["key"]):
                    raise ValueError("Task result identity differs")
                status = _state_kind(record)
                if status == 'COMPLETE' and 'sessions_expected' in record:
                    expected = record['sessions_expected']
                    declared = record.get('session_receipts', [])
                    if (not isinstance(expected, int) or expected < 1
                            or record.get('sessions_complete') != expected
                            or record.get('sessions_failed') or len(declared) != expected):
                        raise ValueError('Completed task has incomplete declared session coverage')
                    for proof in declared:
                        source=(output/proof['path']).resolve()
                        if (not source.is_relative_to((folder/'sessions').resolve())
                                or not source.is_file() or source.is_symlink()
                                or source.stat().st_size != proof['bytes']):
                            raise ValueError('Completed task is missing a declared session receipt')
                task_kind = ("COMPLETE" if status == "COMPLETE" else "SKIPPED" if status.startswith("SKIP")
                             else "ERROR" if status in {"ERROR", "FAILED", "NUMERICAL_ERROR"}
                             else "UNOBSERVED_OR_PARTIAL")
            except (OSError, ValueError, TypeError) as error:
                issues.append({"task": task["key"], "reason": str(error)})
        elif (folder / "state.json").is_file():
            try:
                state = _read(folder / "state.json")
                if state.get("phase") == "ERROR":
                    task_kind = "ERROR"
                elif str(state.get("phase", "")).startswith("SKIP"):
                    task_kind = "SKIPPED"
            except (OSError, ValueError, TypeError) as error:
                issues.append({"task": task["key"], "reason": str(error)})
        task_status[task_kind] += 1
        for receipt_path in sorted((folder / "sessions").glob("*/receipt.json")):
            try:
                if receipt_path.is_symlink() or not receipt_path.resolve().is_relative_to(output):
                    raise ValueError("Session receipt escapes output")
                receipt = _read(receipt_path)
                if (receipt.get("recipe_sha256") != plan.get("recipe_sha256") or
                        receipt.get("task_key") != task["key"]):
                    raise ValueError("Session receipt identity differs")
                status = _state_kind(receipt)
                if status != "COMPLETE":
                    session_status["SKIPPED" if status.startswith("SKIP") else "ERROR"] += 1
                    continue
                descriptors=receipt.get('files', {})
                for proof in (descriptors.values() if isinstance(descriptors, dict) else descriptors):
                    source=output/proof['path']
                    if len(Path(proof['path']).parts) == 1:
                        source=receipt_path.parent/proof['path']
                    if (not source.resolve().is_relative_to(output) or not source.is_file()
                            or source.is_symlink() or source.stat().st_size != proof['bytes']):
                        raise ValueError('Sealed session has a missing or changed artifact')
                path = receipt_path.parent / "metrics.csv"
                if path.is_symlink() or not path.resolve().is_relative_to(output):
                    raise ValueError("Session metrics escape output")
                with path.open("rb") as stream:
                    content = stream.read(_MAX_METRICS + 1)
                if len(content) > _MAX_METRICS:
                    raise ValueError("Session metrics exceed bound")
                _verify_metrics_descriptor(receipt, path, content)
                records = list(csv.DictReader(io.StringIO(content.decode("utf-8"))))
                local = []
                for row in records:
                    # Explicit field conversion rejects malformed/null identity
                    # values instead of silently manufacturing a zero result.
                    person, session = row["participant"], row["session"]
                    if not person or not session:
                        raise ValueError("Missing participant/session identity")
                    seed, generator = int(row["seed"]), int(row["generator"])
                    amplitude, rho = float(row["amplitude"]), float(row["rho"])
                    if (person != str(task["participant"]) or seed != int(task["seed"]) or
                            generator != int(task["generator"]) or amplitude != float(task["amplitude"])):
                        raise ValueError("Metric participant/seed/perturbation differs from prepared task")
                    model, method = row["model"], row["method"]
                    info, k = row["information"], int(row["k"])
                    uid_key = (person, session, seed, generator, amplitude, rho, model, method, info, k)
                    if uid_key in seen:
                        raise ValueError("Duplicate scientific metric identity")
                    numbers = {name: _number(row.get(name)) for name in METRICS}
                    if any(row.get(name) not in (None, "", "null", "None") and numbers[name] is None
                           for name in METRICS):
                        raise ValueError("Nonfinite scientific metric")
                    signature, fit_identity = row.get("query_signature"), row.get("initial_fit_identity")
                    if not signature or not fit_identity:
                        raise ValueError("Missing paired query/initial-fit identity")
                    local.append((uid_key, numbers, signature, fit_identity))
                if len({entry[0] for entry in local}) != len(local):
                    raise ValueError("Duplicate scientific metric identity within session")
                if plan.get("config", {}).get("exhaustive_fixed_matrix"):
                    observed = {(entry[0][5], entry[0][6], entry[0][7], entry[0][8], entry[0][9])
                                for entry in local}
                    missing = _required_conditions() - observed
                    if missing:
                        issues.append({"session_receipt": str(receipt_path.relative_to(output)),
                                       "reason": "Session marked complete with missing fixed conditions",
                                       "missing_condition_count": len(missing)})
                # A rejected session contributes no rows, even if malformed
                # records appear after otherwise valid records in its CSV.
                for key, numbers, signature, fit_identity in local:
                    seen.add(key)
                    person, session, seed, generator, amplitude, rho, model, method, info, k = key
                    aggregate = (person, seed, generator, amplitude, rho, model, method, info, k)
                    grouped.setdefault(aggregate, []).append(numbers)
                    if model in SPATIAL_MODELS and k == 0 and info == "prefix_only" and rho in (0., 1.):
                        pair_key = (person, session, seed, generator, amplitude)
                        pairs.setdefault(pair_key, {})[(rho, method)] = dict(
                            loss=numbers["balanced_NLL"], query=signature, fit=fit_identity)
                    metric_rows += 1
                session_status["COMPLETE"] += 1
            except (OSError, ValueError, KeyError, TypeError) as error:
                session_status["REJECTED"] += 1
                issues.append({"session_receipt": str(receipt_path.relative_to(output)), "reason": str(error)})
    seed_means = {}
    for key, values in grouped.items():
        person, seed, *condition = key
        seed_means.setdefault((person, *condition), []).append((seed, {
            name: _mean([v[name] for v in values]) for name in METRICS}, len(values)))
    participant_rows = []
    for key, values in sorted(seed_means.items()):
        person, generator, amplitude, rho, model, method, info, k = key
        participant_rows.append(dict(participant=person, generator=generator, amplitude=amplitude,
            rho=rho, model=model, method=method, information=info, k=k,
            source_seeds=";".join(str(v[0]) for v in sorted(values)),
            session_seed_rows=sum(v[2] for v in values),
            **{name: _mean([v[1][name] for v in values]) for name in METRICS}))

    # A primary observation is an exact within-session contrast.  All four
    # methods/world rows must bind the same future UIDs and fitted update.
    primary_session = {}
    for key, records in pairs.items():
        required = [(rho, method) for rho in (0., 1.) for method in (PRIMARY_METHOD, ANCHOR_METHOD)]
        if not all(item in records for item in required):
            continue
        records4 = [records[item] for item in required]
        if any(item["loss"] is None for item in records4):
            continue
        if len({item["query"] for item in records4}) != 1 or len({item["fit"] for item in records4}) != 1:
            issues.append({"primary_pair": list(key), "reason": "Paired future UIDs or fixed update differ"})
            continue
        person, session, seed, generator, amplitude = key
        d0 = records[(0., PRIMARY_METHOD)]["loss"] - records[(0., ANCHOR_METHOD)]["loss"]
        d1 = records[(1., PRIMARY_METHOD)]["loss"] - records[(1., ANCHOR_METHOD)]["loss"]
        primary_session.setdefault((person, seed, generator, amplitude), []).append((session, d0, d1))
    primary_seed = {}
    primary_sessions_by_stratum = {}
    for key, values in primary_session.items():
        person, seed, generator, amplitude = key
        primary_seed.setdefault((person, seed), {})[(generator, amplitude)] = (
            _mean([v[1] for v in values]), _mean([v[2] for v in values]))
        primary_sessions_by_stratum[key] = {v[0] for v in values}
    primary_people = {}
    completeness = {}
    people = sorted({key[0] for key in primary_seed})
    for person in people:
        observed_seeds = {seed for p, seed in primary_seed if p == person}
        complete = observed_seeds == set(expected_seeds)
        session_sets = []
        seed_results = []
        for seed in observed_seeds:
            strata = primary_seed[(person, seed)]
            complete &= set(strata) == EXPECTED_PERTURBATIONS
            session_sets.extend(primary_sessions_by_stratum[(person, seed, *s)] for s in strata)
            if set(strata) == EXPECTED_PERTURBATIONS:
                seed_results.append((_mean([v[0] for v in strata.values()]),
                                     _mean([v[1] for v in strata.values()])))
        complete &= bool(session_sets) and all(s == session_sets[0] for s in session_sets)
        completeness[person] = bool(complete)
        if complete:
            primary_people[person] = dict(d_reset=_mean([v[0] for v in seed_results]),
                                         d_persistent=_mean([v[1] for v in seed_results]))
            primary_people[person]["interaction"] = (primary_people[person]["d_reset"] -
                                                      primary_people[person]["d_persistent"])
    completed_all = bool(tasks) and task_status["COMPLETE"] == len(tasks)
    expected_people = {str(task["participant"]) for task in tasks}
    scientific_complete = (completed_all and not issues and bool(primary_people)
                           and set(primary_people) == expected_people
                           and not session_status["ERROR"] and not session_status["REJECTED"])
    statistics_primary = {name: _paired_statistics([v[name] for v in primary_people.values()],
                          alternative="greater" if name == "d_reset" else "less" if name == "d_persistent"
                          else "two-sided")
                          for name in ("interaction", "d_reset", "d_persistent")}
    sign_p = max((statistics_primary[x]["sign_flip_p"] for x in ("d_reset", "d_persistent")
                  if statistics_primary[x]["sign_flip_p"] is not None), default=None)
    means_flip = (statistics_primary["d_reset"]["mean"] is not None and
                  statistics_primary["d_reset"]["mean"] > 0 and
                  statistics_primary["d_persistent"]["mean"] < 0)
    report = dict(schema_version="paper3r13-observer-report-v1", round=13,
        updated_utc=utc(), recipe_sha256=plan.get("recipe_sha256", digest(plan)),
        status="COMPLETE_EXPLORATORY" if scientific_complete else "PARTIAL_EXPLORATORY",
        scientific_completion_claimed=scientific_complete,
        independent_confirmation_available=False,
        scientific_scope="retrospective exploratory replay; historical cohorts are reused; the pilot subset was in source meta_train",
        cohort_roles=sorted({str(task.get("role", "pilot")) for task in tasks}),
        training_controlled=False, independent_unit="participant",
        coverage=dict(expected_tasks=len(tasks), task_status=task_status, session_status=session_status,
                      observed_metric_rows=metric_rows,
                      fully_paired_primary_participants=len(primary_people),
                      observed_primary_participant_completeness=completeness,
                      expected_source_seeds=list(expected_seeds)),
        aggregation="sessions equally within generator/amplitude/source-seed; four perturbation strata equally within seed; seeds equally within participant",
        primary=dict(estimand="(NLL_adapt-NLL_EA)_rho0 - (NLL_adapt-NLL_EA)_rho1",
            model="spatial_head_frozen", methods=[PRIMARY_METHOD, ANCHOR_METHOD],
            information="prefix_only", k=0, participant_values=primary_people,
            statistics=statistics_primary, joint_sign_reversal_p=sign_p,
            observed_mean_sign_reversal=bool(means_flip),
            exploratory_sign_reversal_supported=bool(scientific_complete and means_flip and sign_p is not None and sign_p <= .05),
            interpretation="An interaction alone is not sign reversal. Statistics use complete matched participant vectors only; all results are exploratory, not independent confirmation."),
        limitations=["Missing outcomes are not zero effects.",
            "Repeated seeds, sessions and perturbations do not increase independent participant N.",
            "Source-trained historical pilot participants are not new independent confirmation.",
            "A fixed persistence grid does not establish a unique continuous threshold or physical half-life.",
            "Retrospective label revelation is not measured prospective acquisition-cost savings.",
            "Scheduler completion alone is not scientific completion."], issues=issues)
    data = _csv_bytes(participant_rows)
    atomic_bytes(output / "participant_metrics.csv", data)
    report["artifacts"] = {"participant_metrics": dict(path="participant_metrics.csv", bytes=len(data),
                                        sha256=hashlib.sha256(data).hexdigest())}
    atomic_json(output / "report.json", report)
    return report


def main(argv=None):
    parser = argparse.ArgumentParser(allow_abbrev=False)
    parser.add_argument("--plan", type=Path, required=True)
    args = parser.parse_args(argv)
    result = generate_report(args.plan)
    print(json.dumps({key: result[key] for key in ("status", "coverage", "updated_utc")},
                     ensure_ascii=False), flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
