"""Run under school Python -I -S; add existing venv libraries without .pth hooks."""
from __future__ import annotations
import importlib
import os
from pathlib import Path
import sys
import sysconfig


def activate_paths():
    package = Path(__file__).resolve().parents[1]
    if str(package) not in sys.path:
        sys.path.insert(0, str(package))
    version = 'python%d.%d' % sys.version_info[:2]
    binary = Path(sys.executable).absolute()
    candidates = [binary.parent.parent / lib / version / 'site-packages' for lib in ('lib', 'lib64')]
    candidates += [Path(sysconfig.get_paths()[key]) for key in ('purelib', 'platlib')]
    for path in candidates:
        if path.is_dir() and str(path) not in sys.path:
            sys.path.append(str(path))
    os.environ.setdefault('PYTHONDONTWRITEBYTECODE', '1')
    os.environ.setdefault('PYTHONUNBUFFERED', '1')
    os.environ['CUBLAS_WORKSPACE_CONFIG'] = ':4096:8'
    for name in ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS', 'NUMEXPR_NUM_THREADS'):
        os.environ.setdefault(name, '1')
    return package


def main(argv=None):
    activate_paths()
    args = list(sys.argv[1:] if argv is None else argv)
    if args and args[0] in ('parallel-work','parallel-status','parallel-submit'):
        command={'parallel-work':'work','parallel-status':'status','parallel-submit':'submit'}[args[0]]
        return importlib.import_module('paper3r13.parallel').main([command,*args[1:]])
    if args and args[0] == 'parallel-observer':
        return importlib.import_module('paper3r13.parallel_observer').main(args[1:])
    if args and args[0] == 'observer':
        return importlib.import_module('paper3r13.observer').main(args[1:])
    return importlib.import_module('paper3r13.runtime').main(args)


if __name__ == '__main__':
    raise SystemExit(main())
