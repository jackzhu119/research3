#!/usr/bin/env bash
set +x
set -eu
umask 077
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
mode_selected=false
for arg in "$@"; do
    case "$arg" in
        --run-on-this-gpu|--prepare-only|--backup-only|--check-bundle|--help|-h)
            mode_selected=true ;;
    esac
done
if [ "$mode_selected" = false ]; then
    set -- --run-on-this-gpu "$@"
fi
exec python3 -B paper3_one_click.py "$@"
