# 论文3一键启动

在你本人已经开机的 Linux NVIDIA GPU 服务器上执行。程序会隐藏输入凭证，自动将代码推送至 GitHub 的新研究分支，恢复已冻结的 R2 部署包和数据，建立固定依赖环境，再调用原有受控 pilot 和训练入口。它不管理云实例。

## 使用

服务器须有 Bash、Python 3.10 或以上、Git、可用 NVIDIA 驱动、可连 GitHub/R2 的网络。首次运行建议至少保留 25 GiB 空闲磁盘，另为后续 checkpoint 和结果预留空间；原部署入口会按实际缺失量再次检查磁盘。CUDA 能否用于训练以开机后真实检查为准。

将本 ZIP 上传到服务器，解压后执行：

```bash
unzip -q Paper3_OneClick_20261021.zip
bash Paper3_OneClick/START.sh
```

默认仓库为 `jackzhu119/research3`。自动创建 `research/paper3-oneclick-20261021-xxxxxx` 研究分支，推送后核对远端提交 SHA。仓库须已存在。若使用其他仓库：

```bash
bash Paper3_OneClick/START.sh --repo 你的用户名/仓库名
```

按顺序输入以下五项，所有输入均不回显；粘贴后按 Enter。凭证只在进程内存及必要的子进程环境中使用，不写入脚本、Git 地址、Git 配置或进度文件。

1. GitHub Token：授权目标仓库，需 Contents 读写权限；组织仓库可能还需组织授权。
2. Cloudflare R2 Account ID（32 位）或该账号的 S3 API Endpoint。
3. R2 Bucket 名称：必须是保存本次固定数据包的已有桶。
4. R2 Access Key ID。
5. R2 Secret Access Key：需目标桶对象读写权限。

终端必须支持隐藏输入；不要在聊天、命令参数、Notebook 单元或 shell 历史中填写密钥。保留该终端；长任务可在服务器已有的 tmux/screen 会话中执行。

## 自动执行的顺序

1. 核对本启动包 SHA256；从随包的八个固定纯 Python wheel 加载 R2 SDK，不联网安装初始 SDK。
2. 从 R2 完整 GET 固定 READY 对象，并实际 PUT 一份小型非科学测试记录、完整 GET/SHA256 回读，以验证桶的读写权限。
3. 将白名单内的代码导入独立 Git 历史，推送新研究分支并读取远端 SHA 验证。公开内容包括 Python 源码、测试、依赖锁定文件、启动器和不含凭证的固定发布清单；数据、缓存、用户文档、原 Git 历史和凭证均不进入该提交。
4. 完整 GET 主包、控制补包及各自精确清单，核对固定 SHA256，按清单逐文件核对后合并。已存在的同 SHA 文件明确记录为本地命中；不把命中声称为本次网络 GET。
5. 原入口恢复冻结的 21,573 文件闭包及固定离线依赖；对真正下载的对象完整 GET/SHA256 校验。
6. 原入口检查 CUDA，先通过 200 update 的受控 source pilot 和中断恢复验证，再推进主线 14 方法、3 seeds。主线真实冻结后才推进 Yang/Dreyer 两条独立 source 扩展臂；各项科学门禁仍以原 producer 回执为准。
7. 原训练入口返回或暂停、释放锁后，自动备份其已实际产生的有限结果，并逐对象完整 GET/SHA256 核验。没有产物的阶段不会被宣称完成；失败的训练不会因备份成功而改成成功。

本入口不解封 W7 外测 query，不训练 Ma，不将 CAR3 算作新增独立受试者，不把 `legacy_baseline_v1` 当作新算法，也不改论文1/2的代码或配置。科学拟合和远端实际状态以开机后的真实回执为准。

## 暂不训练 / 只重试备份

只推送、恢复数据和安装环境，暂不拟合：

```bash
bash Paper3_OneClick/START.sh --prepare-only
```

此后执行默认启动命令会沿同一工作目录继续。若训练完成但 R2 备份失败，单独重试备份（只输入四项 R2 信息）：

```bash
bash Paper3_OneClick/START.sh --backup-only
```

只校验随包文件，完全离线、无需凭证：

```bash
bash Paper3_OneClick/START.sh --check-bundle
```

默认工作目录在 `Paper3_OneClick/work_603d299351fa6605/`，也可通过 `--work-dir /绝对路径/新目录` 指定；后续命令必须继续使用同一目录。新目录须为空，禁止指向论文1/2目录。代码发布身份和进度保存在 `RUN_PROGRESS.json`，子步骤日志在 `logs/`，原训练与备份回执位于 `release/paper3_data_plan_603d299351fa6605/` 中。进度文件不含密钥。

遇中断或错误，保留原工作目录、claim、checkpoint 和回执，修复所报告的具体问题，再运行同一命令。不要删除 claim 强行重训，也不要并行启动第二个协调器。训练已正常返回后，默认重试也只补备份；`--backup-only` 始终不发起训练。只备份模式不会更改先前训练的失败状态，进程可能仍返回先前非零训练码。

固定数据闭包：`603d299351fa6605aa0bc258bbbe2c421b2048e5becbeb33521e119a62f20fd7`。
