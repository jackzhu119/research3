Paper3 Round3 portable Weibo2014 numerical cache

Extract the archive into an empty directory. Open:
  ExternalCatalog(existing_project_root, extraction_directory / "weibo" / "manifest.json")

All cache array/event/schema paths in manifest.json are relative to its directory.
The existing project must have the matching frozen input contract; its SHA-256 is recorded in manifest.json. Workers read this cache locally and do not fetch EEG or import SciPy for loading.

10 participants;1580 valid LR trials;B20 uses200 support positions and1380 fixed query trials. All shorter budgets4/8/12/16/20 share the B20 query identities.
This is published-order LR-prefix20 robustness,not verified physical acquisition-prefix20 and not prospective independent confirmation. Original runs are unknown and physical-run tail metrics are disabled.

Raw MAT files,source model weights,and other datasets are absent. LICENSE.txt and LICENSE_EVIDENCE.json document the source-data CC0 terms. ORIGINAL_SOURCES.json records the10 original MAT hashes/URLs/byte counts verified before preparation. ALL10_CACHE_PROOF.json records the actual numerical/schema checks.
